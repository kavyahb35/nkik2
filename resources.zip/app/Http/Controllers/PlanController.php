<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\PlanNotes;
use DB;
class PlanController extends Controller
{
	/* Load plan view blade page */
	public function index(){
		$data['error']='';
		$data['success']='';
		$PlanModel = new PlanNotes();
		$data['listPlans'] = $PlanModel->listPlan();
        return view('plan.plan',$data);
	}
	/* Added new plan code */
	public function create(Request $request){
		$data['error']='';
		$data['success']='';
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$PlanModel = new PlanNotes();
		$Entrycheck = $PlanModel->store($request);
		if($Entrycheck=='1'){
			$data['success'] = 'Added successfully.';
		}
		else if($Entrycheck=='3'){
			$data['error'] = 'Plan already Exist.';
		}else{
			$data['error'] = 'Error occur when added plan.';
		}
		$data['listPlans'] = $PlanModel->listPlan();
		return view('plan.plan',$data);
	}
	/* Search Plan code */
	public function autosearch(Request $request,$search){
		if($search!=''){		
			  $searchname = DB::Table('plan_notes')
			  ->select('*')   
			  ->where('plantext','LIKE','%'.$search.'%')
			  ->orderBy('id', 'DESC')
			  ->get();
			  if(!empty($searchname)){
				  if(isset($searchname[0]->id)!=''){
					  $te = "<div>";
					  foreach($searchname as $name){
						  $te .= "<div class='row'>";
						  $te .= "<div class='col-md-12'>";
						  $te .= "<div class='boxplan'><a href='plan-topic/".$name->id."' target='_blank'>".$name->plantext." <span class='right-align green'>".$name->duedate."</span></a></div>";
						  $te .= "</div>";
						  $te .= "</div>";
					  }
					  $te .= "</div>";
				  }else{
					  $te = "<div><div class='row'>Search result not found</div></div>";
				  }
			  }
			  
			  $datas = $te;
			  echo json_encode($datas); 
			 
		}
	}
	/* Plan action blade page load */
	public function getByPlanId(Request $request,$id){
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$data['success']='';
		$data['error']='';
		$PlanModel = new PlanNotes();
		$data['plan'] = $PlanModel->getRecordById('plan_notes','id',$id);
		return view('plan.plan_action',$data);
	}
	
	/* Edit Plan code */
	public function edit(Request $request,$id){
		$planids = $request->input('planids');
		$PlanModel = new PlanNotes();
		$Entrycheck = $PlanModel->editplan($request);
		if($Entrycheck=='1'){
			 return redirect('plan-topic/'.$planids); 
		}else{
			return redirect('plan-topic/'.$planids); 
		}
	}
	/* delete plan */
	public function deleteplan(Request $request,$id){
		//echo $id;
		$PlanModel = new PlanNotes();
		$Entrycheck = $PlanModel->deleteplan($id);
		echo json_encode(1);
	}
}
