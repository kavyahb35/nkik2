<?php
die;
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DiaryEntry;
use App\DiaryEntryTodo;
use DB;
class DiaryEntryController extends Controller
{
	public function index(){
		$DiaryEntryModel = new DiaryEntry();
		$data['DiaryEntry'] = $DiaryEntryModel->getRecordByDate();
        return view('diary.index',$data);
	}
	/* view 7 diary list page load */
    public function create(Request $request){
		echo 'sdfsdfds';die;
		$currentdatePOST = $request->input('currentdate');
		$UserLoginId = $request->session()->get('UserLoginId');
		$userid = $UserLoginId;
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$currentDate = date('Y-m-d');
		$lastDate = date("Y-m-d", strtotime("$currentDate -1 day"));
		$secondLastDate = date("Y-m-d", strtotime("$currentDate -2 day")); 
		$thirdLastDate = date("Y-m-d", strtotime("$currentDate -3 day")); 
		$fourLastDate = date("Y-m-d", strtotime("$currentDate -4 day")); 
		$fiveLastDate = date("Y-m-d", strtotime("$currentDate -5 day")); 
		$sixLastDate = date("Y-m-d", strtotime("$currentDate -6 day")); 

			$datepickerDate = $request->input('DairyDate');
			$divDate = $request->input('currentdate');
			$todaydate = date('Y-m-d');
			
		
		 if($_POST){
			 $currentdatePOST = $request->input('currentdate');
			 
			 $dateRecord = $DiaryEntryModel->getRecordByDateBypara($currentdatePOST);
			 if(!empty($dateRecord)){
				 if(isset($dateRecord[0]->EntryId)==''){
					 $u_id= session()->get('UserLoginId');
					 $created = date('Y-m-d');
					 $insertDate = $currentdatePOST;
					 DB::table('diary_entries')->insertGetId(
						array('EntryDate' => $insertDate,
							 'UserId' => $u_id,
							 'created_at' => $insertDate,							 
							 )
					);
				 }
			 }
			
			 $data["ajaxdate"]=$currentdatePOST;
			 /* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				if(isset($marketing[0]->NoteText)!=''){
						$data['market_content'] = $marketing;
					}else{
						$data['market_content'] = '';
					}
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				if(isset($report[0]->NoteText)!=''){
						$data['report_content'] = $report;
					}else{
						$data['report_content'] = '';
					}
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				if(isset($notes[0]->NoteText)!=''){
						$data['notes_content'] = $notes;
					}else{
						$data['notes_content'] = '';
					}
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				if(isset($home[0]->NoteText)!=''){
						$data['home_content'] = $home;
					}else{
						$data['home_content'] = '';
					}
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentdatePOST);
			if(!empty($res)){
				if(isset($res[0]->EntryId)!=''){
					$Entry_ID = $res[0]->EntryId;
					$data['SelectedDate'] = $res[0]->EntryDate;
					$DiaryEntryTodoModel = new DiaryEntryTodo();
					$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
					
					if(!empty($primary_habit)){
						foreach($primary_habit as $habit){
						  $primary_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($primary_habitss)){
						if(isset($primary_habitss)!=''){
								$data['primary_habit'] = $primary_habitss;
							}else{
								$data['primary_habit'] = '';
							}	
					}else{
						 $data['primary_habit'] = array();
					}
					
					$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
					
					if(!empty($routine_habit)){
						foreach($routine_habit as $habit){
						  $routine_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($routine_habitss)){
						if(isset($routine_habitss)!=''){
								$data['routine_habit'] = $routine_habitss;
							}else{
								$data['routine_habit'] = '';
							}
					}else{
						 $data['routine_habit'] = array();
					}
					$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
					$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
					$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
					$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
					$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
					$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
				}else{
					$data['SelectedDate'] = '';
					$data['primary_habit'] = array();
					$data['routine_habit'] = array();
				}
			}
			
			
			
			
			
			/* end left form data */
		 }else{
			
		/* Left site form data get by date */
		$data["ajaxdate"]=$currentDate;
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'2','PredefineNoteType');
						
			if(!empty($marketing)){
					if(isset($marketing[0]->NoteText)!=''){
						
						$data['market_content'] = $marketing;
					}else{
						$data['market_content'] = '';
					}
				
			}else{ 
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				if(isset($report[0]->NoteText)!=''){
						$data['report_content'] = $report;
					}else{
						$data['report_content'] = '';
					}
				
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				if(isset($notes[0]->NoteText)!=''){
						$data['notes_content'] = $notes;
					}else{
						$data['notes_content'] = '';
					}
				
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentDate,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				if(isset($home[0]->NoteText)!=''){
						$data['home_content'] = $home;
					}else{
						$data['home_content'] = '';
					}
				
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentDate);
			
			if(!empty($res)){
			   if(isset($res[0]->EntryId)!=''){ 
				   $Entry_ID = $res[0]->EntryId;
					$data['SelectedDate'] = $res[0]->EntryDate;
					$DiaryEntryTodoModel = new DiaryEntryTodo();
					$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
					
					if(!empty($primary_habit)){
						foreach($primary_habit as $habit){
						  $primary_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($primary_habitss)){
						if(isset($primary_habitss)!=''){
								$data['primary_habit'] = $primary_habitss;
							}else{
								$data['primary_habit'] = '';
							}
					   
					}else{
						 $data['primary_habit'] = array();
					}
					
					$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
					
					if(!empty($routine_habit)){
						foreach($routine_habit as $habit){
						  $routine_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($routine_habitss)){
						if(isset($routine_habitss)!=''){
								$data['routine_habit'] = $routine_habitss;
							}else{
								$data['routine_habit'] = '';
							}
						
					}else{
						 $data['routine_habit'] = array();
					}
					$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
					$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
					$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
					$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
					$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
					$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
			   }else{
				   	$records = DB::select("SELECT * FROM `diary_entries` ORDER BY `EntryId` DESC limit 1");
					//print_r($records);die;
				   	if(!empty($records)){
						
						
							$dates = $records[0]->EntryDate;
							$PredefineDetail1 =  DB::table('diary_entries')
								->where('UserId',$userid)
								->where('EntryDate',$dates)				
								->whereNull('PredefinedNoteId')
								 ->limit(1)
								->get();
							if(!empty($PredefineDetail1)){						
								
									
									if(isset($PredefineDetail1[0]->EntryId)!=''){
										
										
										$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$PredefineDetail1[0]->EntryDate,$userid,'2','PredefineNoteType');
						
										if(!empty($marketing)){
												if(isset($marketing[0]->NoteText)!=''){
													$data['market_content'] = $marketing;
												}else{
													$data['market_content'] = '';
												}
											
										}else{ 
											$data['market_content'] = '';
										}
										
										$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$PredefineDetail1[0]->EntryDate,$userid,'4','PredefineNoteType');
										if(!empty($report)){
											if(isset($report[0]->NoteText)!=''){
													$data['report_content'] = $report;
												}else{
													$data['report_content'] = '';
												}
											
										}else{
											$data['report_content'] = '';
										}
										
										$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$PredefineDetail1[0]->EntryDate,$userid,'5','PredefineNoteType');
										if(!empty($notes)){
											if(isset($notes[0]->NoteText)!=''){
													$data['notes_content'] = $notes;
												}else{
													$data['notes_content'] = '';
												}
											
										}else{
											$data['notest_content'] = '';
										}
										
										$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$PredefineDetail1[0]->EntryDate,$userid,'11','PredefineNoteType');
										if(!empty($home)){
											if(isset($home[0]->NoteText)!=''){
													$data['home_content'] = $home;
												}else{
													$data['home_content'] = '';
												}
											
										}else{
											$data['home_content'] = '';
										}
										
										$Entry_ID = $PredefineDetail1[0]->EntryId;
										$data['SelectedDate'] = $PredefineDetail1[0]->EntryDate;
										$DiaryEntryTodoModel = new DiaryEntryTodo();
										$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
										
										if(!empty($primary_habit)){
											foreach($primary_habit as $habit){
											  $primary_habitss[] = $habit->PredefinedNoteId;				  
											}	
										}
										if(!empty($primary_habitss)){
											if(isset($primary_habitss)!=''){
													$data['primary_habit'] = $primary_habitss;
												}else{
													$data['primary_habit'] = '';
												}
										   
										}else{
											 $data['primary_habit'] = array();
										}
										
										$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
										
										if(!empty($routine_habit)){
											foreach($routine_habit as $habit){
											  $routine_habitss[] = $habit->PredefinedNoteId;				  
											}	
										}
										if(!empty($routine_habitss)){
											if(isset($routine_habitss)!=''){
													$data['routine_habit'] = $routine_habitss;
												}else{
													$data['routine_habit'] = '';
												}
											
										}else{
											 $data['routine_habit'] = array();
										}
										$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
										$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
										$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
										$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
										$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
										$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
									}
							}
								
					}else{
						$data['SelectedDate']='';
						$data['routine_habit']= array();
						$data['primary_habit']= array(); 
					}
				   
			  }	
			}
			
		}
			
		
		/* current date for */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$currentDate);
		
		$var = explode('-',$totalnote_ids);
		$data['simpletotalNotes'] = $var[0];
		$recordId = $var[1];
		if($recordId > 1){			
			 $todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$currentDate,'PredefinedNoteId','4');
				
			$data['todaytodo'] = $todo;
			$data['totaltodo'] = $totaltodo;
			$data['TotalReport'] = $totalreport;
		}else{
			$data['todaytodo'] ='0';$data['totaltodo'] ='0';$data['TotalReport'] ='0';
		}
		
		/* second day for */
		
		$lastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$lastDate);
		$var = explode('-',$lastDate_totalnote_ids);
		$data['lastDate_simpletotalNotes'] = $var[0];
		$recordId1 = $var[1];
		if($recordId1 > 1){
						
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$lastDate,'PredefinedNoteId','4');
				
			$data['todaytodo1'] = $todo;
			$data['totaltodo1'] = $totaltodo;
			$data['TotalReport1'] = $totalreport;
		}else{
			$data['todaytodo1'] ='0';$data['totaltodo1'] ='0';$data['TotalReport1'] ='0';
		}
		
		/* third nte */
		
		$secondLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$secondLastDate);
		$var = explode('-',$secondLastDate_totalnote_ids);
		$data['secondLastDate_simpletotalNotes'] = $var[0];
		$recordId2 = $var[1];
		if($recordId2 > 1){
				
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$secondLastDate,'PredefinedNoteId','4');
			 $data['todaytodo2'] = $todo;
			$data['totaltodo2'] = $totaltodo;
			$data['TotalReport2'] = $totalreport;
			
		}else{
			$data['todaytodo2'] ='0';$data['totaltodo2'] ='0';$data['TotalReport2'] ='0';
		}
		/* fourth  note */
		$thirdLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$thirdLastDate);
		$var = explode('-',$thirdLastDate_totalnote_ids);
		$data['thirdLastDate_simpletotalNotes'] = $var[0];
		$recordId3 = $var[1];
		if($recordId3 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$thirdLastDate,'PredefinedNoteId','4');
			 $data['todaytodo3'] = $todo;
			$data['totaltodo3'] = $totaltodo;
			$data['TotalReport3'] = $totalreport;
			
		}else{
			$data['todaytodo3'] ='0';$data['totaltodo3'] ='0';$data['TotalReport3'] ='0';
		}
		/* five note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fourLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fourLastDate_simpletotalNotes'] = $var[0];
		$recordId4 = $var[1];
		if($recordId4 > 1){
						
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fourLastDate,'PredefinedNoteId','4');
			 $data['todaytodo4'] = $todo;
			$data['totaltodo4'] = $totaltodo;
			$data['TotalReport4'] = $totalreport;
			
		}else{
			$data['todaytodo4'] ='0';$data['totaltodo4'] ='0';$data['TotalReport4'] ='0';
		}
		/* Six note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fiveLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fiveLastDate_simpletotalNotes'] = $var[0];
		$recordId5 = $var[1];
		if($recordId5 > 1){
						
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fiveLastDate,'PredefinedNoteId','4');
			 $data['todaytodo5'] = $todo;
			$data['totaltodo5'] = $totaltodo;
			$data['TotalReport5'] = $totalreport;
			
		}else{
			$data['todaytodo5'] ='0';$data['totaltodo5'] ='0';$data['TotalReport5'] ='0';
		}
		
		/* Seven note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$sixLastDate);
		$var = explode('-',$totalnote_ids);
		$data['sixLastDate_simpletotalNotes'] = $var[0];
		$recordId6 = $var[1];
		if($recordId6 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','3');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$sixLastDate,'PredefinedNoteId','4');
			 $data['todaytodo6'] = $todo;
			$data['totaltodo6'] = $totaltodo;
			$data['TotalReport6'] = $totalreport;
			
				/* end left form data */
			}else{
			$data['todaytodo6'] ='0';$data['totaltodo6'] ='0';$data['TotalReport6'] ='0';
		}		
		return view('diary.createdairy',$data);		
	}
	
	
	/* Post date get records */
	public function dateDiaryEntry(Request $request){
		$DairyDatePOST = $request->input('DairyDate');
		
		$UserLoginId = $request->session()->get('UserLoginId');
		$userid = $UserLoginId;
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$currentDate = date('Y-m-d');
		$lastDate = date("Y-m-d", strtotime("$currentDate -1 day"));
		$secondLastDate = date("Y-m-d", strtotime("$currentDate -2 day")); 
		$thirdLastDate = date("Y-m-d", strtotime("$currentDate -3 day")); 
		$fourLastDate = date("Y-m-d", strtotime("$currentDate -4 day")); 
		$fiveLastDate = date("Y-m-d", strtotime("$currentDate -5 day")); 
		$sixLastDate = date("Y-m-d", strtotime("$currentDate -6 day")); 

		$datepickerDate = $request->input('DairyDate');
		$divDate = $request->input('currentdate');
		$todaydate = date('Y-m-d');
		
		if($_POST){
			$currentdatePOST = $DairyDatePOST;
			$dateRecord = $DiaryEntryModel->getRecordByDateBypara($currentdatePOST);
			 if(!empty($dateRecord)){
				 if(isset($dateRecord[0]->EntryId)==''){
					 $u_id= session()->get('UserLoginId');
					 $created = date('Y-m-d');
					 $insertDate = $currentdatePOST;
					 DB::table('diary_entries')->insertGetId(
						array('EntryDate' => $insertDate,
							 'UserId' => $u_id,
							 'created_at' => $insertDate,							 
							 )
					);
				 }
			 }
			
			 $currentdatePOST = $DairyDatePOST;
			 $data["ajaxdate"]=$currentdatePOST;
			 /* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				if(isset($marketing[0]->NoteText)!=''){
						$data['market_content'] = $marketing;
					}else{
						$data['market_content'] = '';
					}
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				if(isset($report[0]->NoteText)!=''){
						$data['report_content'] = $report;
					}else{
						$data['report_content'] = '';
					}
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				if(isset($notes[0]->NoteText)!=''){
						$data['notes_content'] = $notes;
					}else{
						$data['notes_content'] = '';
					}
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				if(isset($home[0]->NoteText)!=''){
						$data['home_content'] = $home;
					}else{
						$data['home_content'] = '';
					}
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentdatePOST);
			if(!empty($res)){
				if(isset($res[0]->EntryId)!=''){
					$Entry_ID = $res[0]->EntryId;
					$data['SelectedDate'] = $res[0]->EntryDate;
					$DiaryEntryTodoModel = new DiaryEntryTodo();
					$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
					
					if(!empty($primary_habit)){
						foreach($primary_habit as $habit){
						  $primary_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($primary_habitss)){
						if(isset($primary_habitss)!=''){
								$data['primary_habit'] = $primary_habitss;
							}else{
								$data['primary_habit'] = '';
							}	
					}else{
						 $data['primary_habit'] = array();
					}
					
					$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
					
					if(!empty($routine_habit)){
						foreach($routine_habit as $habit){
						  $routine_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($routine_habitss)){
						if(isset($routine_habitss)!=''){
								$data['routine_habit'] = $routine_habitss;
							}else{
								$data['routine_habit'] = '';
							}
					}else{
						 $data['routine_habit'] = array();
					}
					$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
					$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
					$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
					$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
					$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
					$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
				}else{
					$data['SelectedDate'] = '';
					$data['primary_habit'] = array();
					$data['routine_habit'] = array();
				}
			}
			
		}
		/* current date for */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$currentDate);
		
		$var = explode('-',$totalnote_ids);
		$data['simpletotalNotes'] = $var[0];
		$recordId = $var[1];
		if($recordId > 1){
						
			 $todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$currentDate,'PredefinedNoteId','4');
					
			$data['todaytodo'] = $todo;
			$data['totaltodo'] = $totaltodo;
			$data['TotalReport'] = $totalreport;
		}else{
			$data['todaytodo'] ='0';$data['totaltodo'] ='0';$data['TotalReport'] ='0';
		}
		
		/* second day for */
		
		$lastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$lastDate);
		$var = explode('-',$lastDate_totalnote_ids);
		$data['lastDate_simpletotalNotes'] = $var[0];
		$recordId1 = $var[1];
		if($recordId1 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$lastDate,'PredefinedNoteId','4');
					
			$data['todaytodo1'] = $todo;
			$data['totaltodo1'] = $totaltodo;
			$data['TotalReport1'] = $totalreport;
		}else{
			$data['todaytodo1'] ='0';$data['totaltodo1'] ='0';$data['TotalReport1'] ='0';
		}
		
		/* third nte */
		
		$secondLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$secondLastDate);
		$var = explode('-',$secondLastDate_totalnote_ids);
		$data['secondLastDate_simpletotalNotes'] = $var[0];
		$recordId2 = $var[1];
		if($recordId2 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$secondLastDate,'PredefinedNoteId','4');
			 $data['todaytodo2'] = $todo;
			$data['totaltodo2'] = $totaltodo;
			$data['TotalReport2'] = $totalreport;
			
		}else{
			$data['todaytodo2'] ='0';$data['totaltodo2'] ='0';$data['TotalReport2'] ='0';
		}
		/* fourth  note */
		$thirdLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$thirdLastDate);
		$var = explode('-',$thirdLastDate_totalnote_ids);
		$data['thirdLastDate_simpletotalNotes'] = $var[0];
		$recordId3 = $var[1];
		if($recordId3 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$thirdLastDate,'PredefinedNoteId','4');
			 $data['todaytodo3'] = $todo;
			$data['totaltodo3'] = $totaltodo;
			$data['TotalReport3'] = $totalreport;
			
		}else{
			$data['todaytodo3'] ='0';$data['totaltodo3'] ='0';$data['TotalReport3'] ='0';
		}
		/* five note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fourLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fourLastDate_simpletotalNotes'] = $var[0];
		$recordId4 = $var[1];
		if($recordId4 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fourLastDate,'PredefinedNoteId','4');
			 $data['todaytodo4'] = $todo;
			$data['totaltodo4'] = $totaltodo;
			$data['TotalReport4'] = $totalreport;
			
		}else{
			$data['todaytodo4'] ='0';$data['totaltodo4'] ='0';$data['TotalReport4'] ='0';
		}
		/* Six note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fiveLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fiveLastDate_simpletotalNotes'] = $var[0];
		$recordId5 = $var[1];
		if($recordId5 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fiveLastDate,'PredefinedNoteId','4');
			 $data['todaytodo5'] = $todo;
			$data['totaltodo5'] = $totaltodo;
			$data['TotalReport5'] = $totalreport;
			
		}else{
			$data['todaytodo5'] ='0';$data['totaltodo5'] ='0';$data['TotalReport5'] ='0';
		}
		
		/* Seven note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$sixLastDate);
		$var = explode('-',$totalnote_ids);
		$data['sixLastDate_simpletotalNotes'] = $var[0];
		$recordId6 = $var[1];
		if($recordId6 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','3');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$sixLastDate,'PredefinedNoteId','4');
			 $data['todaytodo6'] = $todo;
			$data['totaltodo6'] = $totaltodo;
			$data['TotalReport6'] = $totalreport;
			
			}else{
			$data['todaytodo6'] ='0';$data['totaltodo6'] ='0';$data['TotalReport6'] ='0';
		}
         
		return view('diary.createdairy',$data);	
	}
	
		
	/* Insert to store new date in diary entry */
	public function store(Request $request){
		
		$UserId = $request->session()->get('UserLoginId');
		$EntryDate = $request->input('EntryDate');
		$dairyEntry = $this->validate(request(), [
		  'EntryDate' => 'required',
		]);
		if(!empty($dairyEntry)){
			$DiaryEntryModel = new DiaryEntry();
			$Insertrow = $DiaryEntryModel->store($dairyEntry);
			if($Insertrow!='0' && $Insertrow!='' ){
				return redirect('dairy-entry/'.$Insertrow);
				return back()->with('success', 'Diary Entry has been added');
			}else{
				return back()->with('error', 'Diary Entry has been already generated');
			}
		}		
		return back()->with('error', 'Diary Entry has been generate some problem');
	}
	/* create diary entry page load */
	public function edit(Request $request,$id){		
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$id);
		return view('diary.updatecreatedairy',$data);
		//return view('diary.tabdairyentry',$data);
		//return view('diary.dairyentry',$data);
	}
	/* create new diary entry */
	public function update(Request $request,$id){
		
		$DiaryEntryModel = new DiaryEntry();
		$added = $DiaryEntryModel->added($_POST);
		if($added=='1' ){
				//return redirect('dairy');
				return redirect('create-diary');
				
				return back()->with('success', 'Diary Entry has been added');
			}else{
				return back()->with('error', 'Diary Entry has been generate some problem');
			}
		
	}
	/* Get Dairy Entry page load */
	public function getDairy(Request $request,$date){
		$DiaryEntryModel = new DiaryEntry();
		$data['SelectedDate'] = $date;
		$userid = $request->session()->get('UserLoginId');
		$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'2','PredefineNoteType');			
		if(!empty($marketing)){
			if(isset($marketing[0]->NoteText)!=''){
				$data['market_content'] = $marketing;
			}else{
				$data['market_content'] = '';
			}
		}else{
			$data['market_content'] = '';
		}
		
		$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'4','PredefineNoteType');
		if(!empty($report)){
			if(isset($report[0]->NoteText)!=''){
				$data['report_content'] = $report;
			}else{
				$data['report_content'] = '';
			}
		}else{
			$data['report_content'] = '';
		}
		
		$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'5','PredefineNoteType');
		if(!empty($notes)){
			if(isset($notes[0]->NoteText)!=''){
				$data['notes_content'] = $notes;
			}else{
				$data['notes_content'] = '';
			}
		}else{
			$data['notest_content'] = '';
		}
		
		$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$date,$userid,'11','PredefineNoteType');
		if(!empty($home)){
			if(isset($home[0]->NoteText)!=''){
				$data['home_content'] = $home;
			}else{
				$data['home_content'] = '';
			}
		}else{
			$data['home_content'] = '';
		}
		
		$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$date);		
		if(!empty($res)){
			if(isset($res[0]->EntryId)!=''){
				$Entry_ID = $res[0]->EntryId;
				$DiaryEntryTodoModel = new DiaryEntryTodo();
				$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
				
				if(!empty($primary_habit)){
					foreach($primary_habit as $habit){
					  $primary_habitss[] = $habit->PredefinedNoteId;				  
					}	
				}
				if(!empty($primary_habitss)){
					if(isset($primary_habitss)!=''){
						$data['primary_habit'] = $primary_habitss;
					}else{
						$data['primary_habit'] = '';
					}	
				}else{
					 $data['primary_habit'] = array();
				}
				
				$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
				
				if(!empty($routine_habit)){
					foreach($routine_habit as $habit){
					  $routine_habitss[] = $habit->PredefinedNoteId;				  
					}	
				}
				if(!empty($routine_habitss)){
					if(isset($routine_habitss)!=''){
						$data['routine_habit'] = $routine_habitss;
					}else{
						$data['routine_habit'] = '';
					}
				}else{
					 $data['routine_habit'] = array();
				}
				
				$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
				$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
				$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
				$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
				$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');
				
				
				$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
				$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
				$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);	
			}else{
				$data['routine_habit'] = array();
				 $data['primary_habit'] = array();
			}
		}
		
		
		return view('diary.editdairyentry',$data);
		//return view('diary.tabeditdairyentry',$data);
		//return view('diary.editdairyentry',$data);
			
	}
	/* Edit data entry */
	public function updateEntry(Request $request,$date){
		  //  echo '<pre>';print_r($_POST);die;
			$DiaryEntryModel = new DiaryEntry();
			$result = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$date);
			$Entry_ID = $result[0]->EntryId;
			
			
			$DiaryEntryTodoModel = new DiaryEntryTodo();
			$destroy = $DiaryEntryTodoModel->destroyId($Entry_ID);
			$destroyEntry = $DiaryEntryTodoModel->destroyedEntry($date);
			if($destroy == '1' && $destroyEntry =='1'){
				$added = $DiaryEntryModel->edited($_POST);
				return redirect('create-diary');
			}
			return redirect('create-diary');
			
	}
	/* Delete diary entry */
	public function deleteEntry(Request $request,$id){
		   $DiaryEntryModel = new DiaryEntry();
			$result = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryId',$id);
			$Entry_Date = $result[0]->EntryDate;
			
			$DiaryEntryModel->destroyedEntry('diary_entries','EntryDate',$Entry_Date);
			$DiaryEntryModel->destroyedEntry('diary_entry_todos','EntryId',$id);
			echo json_encode('1');
	}
	
	/* View Diary Entry page load */
	public function viewDiaryEntry(Request $request){		
		$DairyDate = $request->input('DairyDate');
		$DiaryEntryModel = new DiaryEntry();
		$userId = session()->get('UserLoginId');
	    $Date = date('Y-m-d');
		$checkRecord = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$DairyDate);
		if($DairyDate!=''){
			if(!empty($checkRecord)){
				if(isset($checkRecord[0]->EntryId)!=''){
					return redirect('dairy/'.$DairyDate.'/get');
				}else{
					$EntryRecord = DB::table('diary_entries')
					->where('EntryDate',$DairyDate)
					->where('UserId',$userId)
					->get();
					if(!empty($EntryRecord)){
						if(isset($EntryRecord[0]->EntryId)!=''){
							return 0;
						}else{
							$InsertID = DB::table('diary_entries')->insertGetId(
							array('EntryDate' => $DairyDate,
								 'UserId' => $userId,
								 'created_at' => $Date,
								 
								 )
						);
						return redirect('dairy-entry/'.$InsertID);
						}
						
					}
				}
			}else{
				$EntryRecord = DB::table('diary_entries')
				->where('EntryDate',$DairyDate)
				->where('UserId',$userId)
				->get();
				if(!empty($EntryRecord)){
					if(isset($EntryRecord[0]->EntryId)!=''){
						return 0;
					}else{
						$InsertID = DB::table('diary_entries')->insertGetId(
						array('EntryDate' => $DairyDate,
							 'UserId' => $userId,
							 'created_at' => $Date,
							 
							 )
					);
					return redirect('dairy-entry/'.$InsertID);
					
					}
					
				}
			}
		}else{
			return back()->with('error', 'Please select date from calender');
		}
		
	}
	
	/* View Diary entry */
	public function viewEntry(Request $request,$id){
		echo $id;
	}
	
	/* Wellness section edit form code*/
	public function wellnessedit(Request $request){		
		if($_POST){
			 $mynewdate = $request->input('mynewdate');
			
			$habit = $request->input('habit');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entry_todos','EntryId',$record[0]->EntryId,'PredefineType','1');
					 $DiaryEntryModel->habitedit($habit,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* Marketing section edit form code*/
	public function marketedit(Request $request){		
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$marketing = $request->input('marketing');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					// $DiaryEntryModel->destroyedEntrywithpara('diary_entries','EntryDate',$mynewdate,'PredefinedNoteId','4');
					 $DiaryEntryModel->marketedit($marketing,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* Marketing section add form code*/
	public function marketadd(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$marketing = $request->input('marketing1');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->marketedit1($marketing,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* To do section edit form code*/
	public function todoeditfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$todostatusnews = $request->input('todostatusnews');
			$todotextnews = $request->input('todotextnews');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entry_todos','EntryId',$record[0]->EntryId,'PredefineType','3');
					 $DiaryEntryModel->todoeditfrm($todostatusnews,$todotextnews,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* To do section add form code */
	public function todoaddfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$todostatusnewsss = $request->input('todostatusnewsss');
			$todotextnewsss = $request->input('todotextnewsss');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->todoaddfrm($todostatusnewsss,$todotextnewsss,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* Report section add form code */
	public function reportaddfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$reports = $request->input('reports');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->reportedit($reports,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* Report section add form code */
	public function reporteditfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$report = $request->input('report');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entries','EntryDate',$mynewdate,'PredefinedNoteId','4');
					 $DiaryEntryModel->reportedit($report,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* note section edit form code */
	public function noteseditfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$notes = $request->input('notes');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entries','EntryDate',$mynewdate,'PredefinedNoteId','5');
					 $DiaryEntryModel->notesedit($notes,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
		
	}
	/* note section add form code */
	public function notesaddfrm(Request $request){
		 if($_POST){
			$mynewdate = $request->input('mynewdate');
			$notes = $request->input('notesss');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->notesedit($notes,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		} 
		
	}
	/* idea section edit form code */
	public function ideaeditfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$ideaatus = $request->input('ideaatus');
			$createiveidea = $request->input('createiveidea');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entry_todos','EntryId',$record[0]->EntryId,'PredefineType','4');
					 $DiaryEntryModel->ideaeditfrm($ideaatus,$createiveidea,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* idea section add form code */
	public function ideaaddfrm(Request $request){		
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$ideaatus = $request->input('ideaatus');
			$createiveidea = $request->input('createiveidea');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->ideaaddfrm($ideaatus,$createiveidea,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* hate section edit form code */
	public function hateeditfrm(Request $request){
		
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$fivehatenote = $request->input('fivehatenote');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					$DiaryEntryModel->destroyedEntrywithpara1($record[0]->EntryId);
					$DiaryEntryModel->hatesedit($fivehatenote,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* like section edit form code */
	public function likeeditfrm(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$fivelikenote = $request->input('fivelikenote');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					// $DiaryEntryModel->destroyedEntrywithpara1($record[0]->EntryId);
					 $DiaryEntryModel->likeedit($fivelikenote,$record[0]->EntryId);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* home section edit form code */
	public function homeeditfrm(Request $request){
		
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$home = $request->input('home');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entries','EntryDate',$mynewdate,'PredefinedNoteId','11');
					 $DiaryEntryModel->homeedit($home,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		}
		
	}
	/* home section add form code */
	public function homeaddfrm(Request $request){
		
		 if($_POST){
			$mynewdate = $request->input('mynewdate');
			$homess = $request->input('homess');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->homeedit($homess,$mynewdate);
				}
			}
			return redirect('diary-entries/'.$mynewdate);
		} 
		
	}
	/* routine habit section edit form code */
	public function routineformedit(Request $request){
		if($_POST){
			$mynewdate = $request->input('mynewdate');
			$secondNotes = $request->input('secondNotes');
			$secondsimpleNotesstatus = $request->input('secondsimpleNotesstatus');
			$secondsimpleNotes = $request->input('secondsimpleNotes');
			
			//--- routine note ----------
			$secondNotes = $request->input('secondNotes');
			$DiaryEntryModel = new DiaryEntry();
			$record = $DiaryEntryModel->getRecordByDateBypara($mynewdate);
			if(!empty($record)){
				if(isset($record[0]->EntryId)!=''){
					 $DiaryEntryModel->destroyedEntrywithpara('diary_entry_todos','EntryId',$record[0]->EntryId,'PredefineType','2');
					 $DiaryEntryModel->routineedit($secondNotes,$record[0]->EntryId);
				}
			}
			//---------------------------
			
			//$DiaryEntryModel->destroyedEntrywithpara('diary_entry_todos','EntryId',$record[0]->EntryId,'PredefineType','5');
			$DiaryEntryModel->primarynoteedit($secondsimpleNotesstatus,$secondsimpleNotes,$record[0]->EntryId);
			
			return redirect('diary-entries/'.$mynewdate);
		}
	}
	/* form post by date  */
	public function byDateEntry(Request $request,$date){
		$DairyDatePOST = $date;
		$UserLoginId = $request->session()->get('UserLoginId');
		$userid = $UserLoginId;
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$DiaryEntryModel = new DiaryEntry();
		$data['PrimaryNote'] = $DiaryEntryModel->getRecord('1');
		$data['SecondNote'] = $DiaryEntryModel->getRecord('2');
		$currentDate = date('Y-m-d');
		$lastDate = date("Y-m-d", strtotime("$currentDate -1 day"));
		$secondLastDate = date("Y-m-d", strtotime("$currentDate -2 day")); 
		$thirdLastDate = date("Y-m-d", strtotime("$currentDate -3 day")); 
		$fourLastDate = date("Y-m-d", strtotime("$currentDate -4 day")); 
		$fiveLastDate = date("Y-m-d", strtotime("$currentDate -5 day")); 
		$sixLastDate = date("Y-m-d", strtotime("$currentDate -6 day")); 

		$data['SelectedDate']=$date;
		$data['primary_habit']='';
		
		
			
			 $currentdatePOST = $date;
			 $data["ajaxdate"]=$currentdatePOST;
			 /* Left site form data get by date */
		
			$marketing = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'2','PredefineNoteType');			
			if(!empty($marketing)){
				if(isset($marketing[0]->NoteText)!=''){
						$data['market_content'] = $marketing;
					}else{
						$data['market_content'] = '';
					}
			}else{
				$data['market_content'] = '';
			}
			
			$report = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'4','PredefineNoteType');
			if(!empty($report)){
				if(isset($report[0]->NoteText)!=''){
						$data['report_content'] = $report;
					}else{
						$data['report_content'] = '';
					}
			}else{
				$data['report_content'] = '';
			}
			
			$notes = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'5','PredefineNoteType');
			if(!empty($notes)){
				if(isset($notes[0]->NoteText)!=''){
						$data['notes_content'] = $notes;
					}else{
						$data['notes_content'] = '';
					}
			}else{
				$data['notest_content'] = '';
			}
			
			$home = $DiaryEntryModel->getRecordByDateByParamerer('diary_entries',$currentdatePOST,$userid,'11','PredefineNoteType');
			if(!empty($home)){
				if(isset($home[0]->NoteText)!=''){
						$data['home_content'] = $home;
					}else{
						$data['home_content'] = '';
					}
			}else{
				$data['home_content'] = '';
			}
			$res = $DiaryEntryModel->getRecordByDateLimit('diary_entries','EntryDate',$currentdatePOST);
			if(!empty($res)){
				if(isset($res[0]->EntryId)!=''){
					$Entry_ID = $res[0]->EntryId;
					$data['SelectedDate'] = $res[0]->EntryDate;
					$DiaryEntryTodoModel = new DiaryEntryTodo();
					$primary_habit= $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'1');
					
					if(!empty($primary_habit)){
						foreach($primary_habit as $habit){
						  $primary_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($primary_habitss)){
						if(isset($primary_habitss)!=''){
								$data['primary_habit'] = $primary_habitss;
							}else{
								$data['primary_habit'] = '';
							}	
					}else{
						 $data['primary_habit'] = array();
					}
					
					$routine_habit = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'2');
					
					if(!empty($routine_habit)){
						foreach($routine_habit as $habit){
						  $routine_habitss[] = $habit->PredefinedNoteId;				  
						}	
					}
					if(!empty($routine_habitss)){
						if(isset($routine_habitss)!=''){
								$data['routine_habit'] = $routine_habitss;
							}else{
								$data['routine_habit'] = '';
							}
					}else{
						 $data['routine_habit'] = array();
					}
					$data['todo'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'3');
					$data['create_idea'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'4');
					$data['second_simple_habit'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'5');
					$data['hates'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'7');
					$data['likes'] = $DiaryEntryTodoModel->getRecordByIdType('diary_entry_todos','EntryId',$Entry_ID,'8');			
					$data['thirdNote'] = $DiaryEntryModel->getRecordById('diary_entries','EntryId',$Entry_ID);
				}else{
					$data['SelectedDate'] = $date;
					$data['primary_habit'] = array();
					$data['routine_habit'] = array();
				}
			}
			
		
		/* current date for */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$currentDate);
		
		$var = explode('-',$totalnote_ids);
		$data['simpletotalNotes'] = $var[0];
		$recordId = $var[1];
		if($recordId > 1){
				
			 $todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$currentDate,'PredefinedNoteId','4');
			
			$data['todaytodo'] = $todo;
			$data['totaltodo'] = $totaltodo;
			$data['TotalReport'] = $totalreport;
		}else{
			$data['todaytodo'] ='0';$data['totaltodo'] ='0';$data['TotalReport'] ='0';
		}
		
		/* second day for */
		
		$lastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$lastDate);
		$var = explode('-',$lastDate_totalnote_ids);
		$data['lastDate_simpletotalNotes'] = $var[0];
		$recordId1 = $var[1];
		if($recordId1 > 1){
				
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3','IsActive','1');
			 $totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId1,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$lastDate,'PredefinedNoteId','4');
					
			$data['todaytodo1'] = $todo;
			$data['totaltodo1'] = $totaltodo;
			$data['TotalReport1'] = $totalreport;
		}else{
			$data['todaytodo1'] ='0';$data['totaltodo1'] ='0';$data['TotalReport1'] ='0';
		}
		
		/* third nte */
		
		$secondLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$secondLastDate);
		$var = explode('-',$secondLastDate_totalnote_ids);
		$data['secondLastDate_simpletotalNotes'] = $var[0];
		$recordId2 = $var[1];
		if($recordId2 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId2,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$secondLastDate,'PredefinedNoteId','4');
			 $data['todaytodo2'] = $todo;
			$data['totaltodo2'] = $totaltodo;
			$data['TotalReport2'] = $totalreport;
			
		}else{
			$data['todaytodo2'] ='0';$data['totaltodo2'] ='0';$data['TotalReport2'] ='0';
		}
		/* fourth  note */
		$thirdLastDate_totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$thirdLastDate);
		$var = explode('-',$thirdLastDate_totalnote_ids);
		$data['thirdLastDate_simpletotalNotes'] = $var[0];
		$recordId3 = $var[1];
		if($recordId3 > 1){
				
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId3,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$thirdLastDate,'PredefinedNoteId','4');
			 $data['todaytodo3'] = $todo;
			$data['totaltodo3'] = $totaltodo;
			$data['TotalReport3'] = $totalreport;
			
		}else{
			$data['todaytodo3'] ='0';$data['totaltodo3'] ='0';$data['TotalReport3'] ='0';
		}
		/* five note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fourLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fourLastDate_simpletotalNotes'] = $var[0];
		$recordId4 = $var[1];
		if($recordId4 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId4,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fourLastDate,'PredefinedNoteId','4');
			 $data['todaytodo4'] = $todo;
			$data['totaltodo4'] = $totaltodo;
			$data['TotalReport4'] = $totalreport;
			
		}else{
			$data['todaytodo4'] ='0';$data['totaltodo4'] ='0';$data['TotalReport4'] ='0';
		}
		/* Six note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$fiveLastDate);
		$var = explode('-',$totalnote_ids);
		$data['fiveLastDate_simpletotalNotes'] = $var[0];
		$recordId5 = $var[1];
		if($recordId5 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3','IsActive','1');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId5,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$fiveLastDate,'PredefinedNoteId','4');
			 $data['todaytodo5'] = $todo;
			$data['totaltodo5'] = $totaltodo;
			$data['TotalReport5'] = $totalreport;
			
		}else{
			$data['todaytodo5'] ='0';$data['totaltodo5'] ='0';$data['TotalReport5'] ='0';
		}
		
		/* Seven note */
		$totalnote_ids = $DiaryEntryModel->CountSimpleNotes($UserLoginId,$sixLastDate);
		$var = explode('-',$totalnote_ids);
		$data['sixLastDate_simpletotalNotes'] = $var[0];
		$recordId6 = $var[1];
		if($recordId6 > 1){
			
			$todo = $DiaryEntryModel->CountSimpleNotesWithStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','1','IsActive','3');
			$totaltodo = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entry_todos','EntryId',$recordId6,'PredefineType','3');
			 
			 $totalreport = $DiaryEntryModel->CountSimpleNotesWithoutStatus('diary_entries','EntryDate',$sixLastDate,'PredefinedNoteId','4');
			 $data['todaytodo6'] = $todo;
			$data['totaltodo6'] = $totaltodo;
			$data['TotalReport6'] = $totalreport;
			
			}else{
			$data['todaytodo6'] ='0';$data['totaltodo6'] ='0';$data['TotalReport6'] ='0';
		}
         
		return view('diary.createdairy',$data);
	}
			
}
