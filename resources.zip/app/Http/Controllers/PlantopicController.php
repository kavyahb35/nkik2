<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\PlanNotesText;
use DB;
class PlantopicController extends Controller
{
	/* Plan action blade page load */
	public function index(Request $request,$id){
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$data['checkall']='';
		$data['success']='';
		$data['error']='';
		$TopicModel = new PlanNotesText();
		$data['plan'] = $TopicModel->getRecordById('plan_notes','id',$id);
		$data['listPlans'] = $TopicModel->getRecordByIdtwopara('plan_notes_texts','planid',$id);
		
		return view('plan.plan_action',$data);
	}
	/* Added new plan code */
	public function create(Request $request,$id){
		$data['checkall']='';
		$data['error']='';
		$data['success']='';
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$TopicModel = new PlanNotesText();
		$Entrycheck = $TopicModel->store($request);
		if($Entrycheck=='1'){
			$data['success'] = 'Added successfully.';
		}
		else{
			$data['error'] = 'Error occur when added plan.';
		}
		$data['plan'] = $TopicModel->getRecordById('plan_notes','id',$id);
		$data['listPlans'] = $TopicModel->getRecordById('plan_notes_texts','IsDeleted','1');
		
		return view('plan.plan_action',$data);
	}
	/* View action in popup */
	public function viewAction(Request $request,$id){
		$data['checkall']='';
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$TopicModel = new PlanNotesText();
		$topicdetails = $TopicModel->getRecordById('plan_notes_texts','id',$id);
		if(!empty($topicdetails)){
			$action ="<div>";
			foreach($topicdetails as $topic){
				$action .= "<input type='hidden' name='topicid' value='".$topic->id."' class='form-control'>";
				$action .= "<input type='hidden' name='planid' value='".$topic->planid."' class='form-control'>";
				$action .= "<input type='text' name='topics' value='".$topic->topictext."' class='form-control'>";
			}
			$action .= "</div>";
		}
		$datatopic = $action;
		echo json_encode($datatopic);
	}
	/* Edit plan action in popup */
	public function updateAction(Request $request){
		$data['checkall']='';
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$planid = $request->input('planid');
		$TopicModel = new PlanNotesText();
		$Entrycheck = $TopicModel->updatetopic($request);
		return redirect('plan-topic/'.$planid); 
	}
	/* Delete plan action */
	public function deleteAction(Request $request,$id){
		$data['checkall']='';
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$TopicModel = new PlanNotesText();
		$Entrycheck = $TopicModel->removeAction($id);
		echo json_encode('1');
	}
	/* All plan action/topic list */
	public function allPlanTopic(Request $request,$id){
		$UserLoginId = $request->session()->get('UserLoginId');
		if($UserLoginId == ''){
			 return redirect('index'); 
		}
		$allval = $request->input('allval');
		$plnid = $request->input('plnid');
		if($allval=='1'){
		$data['success']='';
		$data['error']='';
		$TopicModel = new PlanNotesText();
		$data['plan'] = $TopicModel->getRecordById('plan_notes','id',$plnid);
		$data['listPlans'] = $TopicModel->getRecordById('plan_notes_texts','planid',$plnid);
		$data['checkall']='1';
		return view('plan.plan_action',$data);
		}
		 return redirect('plan-topic/'.$plnid); 
	}
	
}
