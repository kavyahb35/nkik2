<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DiaryEntry;
use App\DiaryEntryTodo;
use DB;
class TagController extends Controller
{
	public function index(){
        return view('common.tag');
	}
	
}
