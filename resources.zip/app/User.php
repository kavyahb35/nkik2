<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
         'Email', 'Password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'Password', 'remember_token',
    ];
    /* Authentication  */
    public function authentication($request){
		 $Email = $request->input('Email');
		 $Password = $request->input('Password');		
		 $encPassword=base64_encode($Password);
		 
		 $userDetail = DB::table('users')
				->where('Email',$Email)
				->where('Password',$encPassword)
				->where("IsActive",'1')
				->get();	
		if(!empty($userDetail)){
			
			foreach($userDetail as $detail){
									
					if($detail->Id!=''){
						$Id = $detail->Id;
						$UserEmail = $detail->Email;
						$FirstName = $detail->FirstName;				
						$request->session()->put('UserLoginId', $Id);
						$request->session()->put('UserLoginEmail', $UserEmail);
						$request->session()->put('UserLoginName', $FirstName);
						return 1;
					}else{
						
						return 0;
					}	
					return 0;
					
				}
				return 0;
		}else{
			return 0;
		}
		
	}
}
