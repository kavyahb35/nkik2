<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class PlanNotes extends Model
{
    /* Addd new plan function */
    public function store($request){
		$duedate = $request->input('duedate');
		$plantext = $request->input('plantext');
		$userid = $request->session()->get('UserLoginId');
		if($duedate!='' && $plantext!='' && $userid!=''){
			
			$EntryRecord = DB::table('plan_notes')
				->where('duedate',$duedate)
				->where('UserId',$userid)
				->where('plantext',$plantext)
				->get();
				if(!empty($EntryRecord)){
					if(isset($EntryRecord[0]->id)!=''){
						return 3;
					}else{
						DB::table('plan_notes')->insertGetId(
						array('duedate' => $duedate,
							'UserId' => $userid,
							'plantext'=>$plantext,
							'created_at' => date('Y-m-d H:i:s')
							)
						);
						return 1;
					}
					
				}else{
					return 2;
				}
			
			
		}else{
			return 2;
		}
	}
	/* List of plans function */
	public function listPlan(){
		$userid = session()->get('UserLoginId');
		$EntryRecord = DB::table('plan_notes')
				->where('UserId',$userid)
				->orderBy('id', 'DESC')
				->get();
		return $EntryRecord;
	}
	/* Edit plan function */
	public function editplan($request){		
		$planids = $request->input('planids');
		$plantext = $request->input('plantext');
		$duedate = $request->input('duedate');
		$userid = $request->session()->get('UserLoginId');
		
		if($plantext!='' && $duedate!='' && $planids!=''){
			DB::table('plan_notes')
				->where('id', $planids)
				->update(
				array(
					'duedate' => $duedate,
					'UserId' => $userid,
					'plantext'=>$plantext,
					'updated_at' => date('Y-m-d H:i:s')
					 )
			);
			return 1;
		}
		return 0;
		
	}
	/* Delete Plan function */
	public function deleteplan($id){
		if($id!=''){
			DB::delete('delete from plan_notes  where id= ?',[$id]);
			DB::delete('delete from plan_topics  where planid= ?',[$id]);
			return 1;
		}
	}
}
