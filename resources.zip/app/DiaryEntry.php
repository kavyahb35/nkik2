<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class DiaryEntry extends Model
{
	protected $fillable = ['EntryDate'];

	/* Added new entry */
	public function store($request){
		$EntryDate = $request['EntryDate'];
		$userId = session()->get('UserLoginId');
		$Date = date('Y-m-d');
		if($EntryDate!=''){	
						
			$EntryRecord = DB::table('diary_entries')
				->where('EntryDate',$EntryDate)
				->where('UserId',$userId)
				->get();
				if(!empty($EntryRecord)){
					if(isset($EntryRecord[0]->EntryId)!=''){
						return 0;
					}else{
						$InsertID = DB::table('diary_entries')->insertGetId(
						array('EntryDate' => $EntryDate,
							 'UserId' => $userId,
							 'created_at' => $Date,
							 
							 )
					);
					return $InsertID;
					}
					
				}
				
		}return 0;

	}
	/* Get record */
	public function getRecord($type){
		$PredefineDetail = DB::table('predefined_notes')
			->where('PredefinedNoteType',$type)
			->where("IsActive",'1')
			->get();
		return $PredefineDetail;
	}
	/* Get record by Id */
	public function getRecordById($tablename,$parameter,$value){
		$PredefineDetail = DB::table($tablename)
			->where($parameter,$value)				
			->get();
		return $PredefineDetail;
	}
	/* Get record by date */
	public function getRecordByDate(){
		$PredefineDetail = DB::table('diary_entries')
			->whereNull('PredefinedNoteId')	 
			->get();
		return $PredefineDetail;
	}
	/* Count simple notes */
	public function CountSimpleNotes($userId,$date){
		/* $PredefineDetail =  DB::table('diary_entries')
			->where('UserId',$userId)
			->where('EntryDate',$date)				
			->whereNotNull('PredefinedNoteId')
			->get();
		
			$totalnote = count($PredefineDetail);
			 */
			$PredefineDetail1 =  DB::table('diary_entries')
			->where('UserId',$userId)
			->where('EntryDate',$date)				
			->whereNull('PredefinedNoteId')
			 ->limit(1)
			->get();
			
			if(isset($PredefineDetail1[0]->EntryId)!=''){
				return 2;
			}else{
				return 0;
			}
			/*	print_r($PredefineDetail1);die;
			if(!empty($PredefineDetail1))
			{
				
				if(isset($PredefineDetail1[0]->EntryId)!=""){
					
				}
				 	if(isset($PredefineDetail1[0]->EntryId)!=""){
						$ids = $PredefineDetail1[0]->EntryId;
						$hate =  DB::table('diary_entry_todos')
						->where('EntryId',$ids)
						->where('PredefineType','7')				
						->where('Title','<>','')
						->get();
						$hates = count($hate);
						
						$like =  DB::table('diary_entry_todos')
						->where('EntryId',$ids)
						->where('PredefineType','8')				
						->where('Title','<>','')
						->get();
						$count = count($like);
						$totlasimplenote = $totalnote + $hates +$count;
						
					return	$retun = $totlasimplenote.'-'.$ids;
						
					}else{
						return $retun = '0-0';
					}
					return $retun = '0-0'; 
			}*/
			
			
	//return $retun;
	}

	/* wellness habit  */
	public function SimpleNotesWithStatus($table,$para1,$val1,$para2,$val2,$para3,$val3){
		$PredefineDetail =  DB::table($table)
			->where($para1,$val1)
			->where($para2,$val2)				
			->where($para3,$val3)
			->get();
		
		return $PredefineDetail;
			
	}
	/* Count simple notes with status */
	public function CountSimpleNotesWithStatus($table,$para1,$val1,$para2,$val2,$para3,$val3){
		//echo '-- '.$val1.' -- '.$val2.'=='.$val3;
		$PredefineDetail =  DB::table($table)
			->where($para1,$val1)
			->where($para2,$val2)				
			->where($para3,$val3)
			->get();
			
		$count = count($PredefineDetail);
		return $count;
	}
	public function CountSimpleNotesWithStatus4value($table,$para1,$val1,$para2,$val2,$para3,$val3,$para4,$val4){
		$PredefineDetail =  DB::table($table)
			->where($para1,$val1)
			->where($para2,$val2)				
			->where($para3,$val3)
			->where($para4,$val4)
			->get();
		$count = count($PredefineDetail);
		return $count;
	}
	
	
	/* Count simple notes without status */
	public function CountSimpleNotesWithoutStatus($table,$para1,$val1,$para2,$val2){
		$PredefineDetail =  DB::table($table)
			->where($para1,$val1)
			->where($para2,$val2)
			->get();
			$count = count($PredefineDetail);
		return $count;
			
	}
	/* Get record by date with limit  */
	public function getRecordByDateLimit($tablename,$para,$val){
		$PredefineDetail = DB::table($tablename)
			->where($para,$val)	
			->whereNull('PredefinedNoteId')
			->limit(1)	 //whereNotNull
			->get();
			
		return $PredefineDetail;
	}
	/* Get recode by date by userid , pre-define note Id */
	public function getRecordByDateByParamerer($tablename,$date,$userid,$parameter,$parameter1){	 
		$PredefineDetail = DB::table($tablename)
			->where('EntryDate',$date)	
			->where('UserId',$userid)	
			->where('PredefinedNoteId',$parameter)	
			->where($parameter1,'1')				
			->get();
			
		return $PredefineDetail;
	}
	/* Insert function entry */
	public function added($request){
		if(isset($request['habit'])!=''){
		  $habit = $request['habit'];
		}else {
		  $habit = '';	
		}
		$EnterId = $request['EnterId'];
		$EntryDate = $request['EntryDate'];
		if(isset($request['marketing'])!=''){
		  $marketing = $request['marketing'];
		}else {
		  $marketing = '';	
		}
		
		if(isset($request['todotextnews'])!=''){
		  $todotextnews = $request['todotextnews'];
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($request['todostatusnews'])){
		   $todostatusnews = $request['todostatusnews'];
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		if(isset($request['report'])!=''){
		  $report = $request['report'];
		}else {
		  $report = '';	
		}
		if(isset($request['notes'])!=''){
		  $notes = $request['notes'];
		}else {
		  $notes = '';	
		}

		if(isset($request['createiveidea'])!=''){
		  $createiveidea = $request['createiveidea'];
		}else {
		  $createiveidea = array();	
		}
		$createiveidea = $request['createiveidea'];
		$createiveidea_array = array_map('current', $createiveidea);
		if(isset($request['ideaatus'])){
		   $ideaatus = $request['ideaatus'];
		   $ideaatuss = array_map('current', $ideaatus);
		}else{
			$ideaatus = array();
			$ideaatuss = array();			
		}
		if(isset($request['secondNotes'])!=''){
		  $secondNotes = $request['secondNotes'];
		}else {
		  $secondNotes = array();	
		}		  
	  
		if(isset($request['secondsimpleNotes'])!=''){			  
		  $secondsimpleNotes = $request['secondsimpleNotes'];
		   $secondsimpleNotes_array = array_map('current', $secondsimpleNotes);
		}else {
		  $secondsimpleNotes_array = array();	
		}
		
		if(isset($request['secondsimpleNotesstatus'])!=''){			  
		  $secondsimpleNotesstatus = $request['secondsimpleNotesstatus'];
		   $secondsimpleNotesstatus_array = array_map('current', $secondsimpleNotesstatus);
		}else {
		  $secondsimpleNotesstatus_array = array();	
		}
		
		if(isset($request['fivehatenote'])!=''){
		  $fivehatenote = $request['fivehatenote'];
		}else {
		  $fivehatenote = array();	
		}
		if(isset($request['fivelikenote'])!=''){
		  $fivelikenote = $request['fivelikenote'];
		}else {
		  $fivelikenote = array();	
		}
		if(isset($request['home'])!=''){
		  $home = $request['home'];
		}else {
		  $home = '';	
		}		 
	  $array = array_map('current', $todotextnews);
	  
	  	 
	 // -- primary habit
	 if(!empty($habit)){
		 $count = count($habit);	
		 for($i=0;$i<$count;$i++){			
			/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => $habit[$i],
				 'EntryId' => $EnterId,
				 'IsActive' => '1',
				 'PredefineType'=>'1'					 
				 )
			); */
		}
	 }
	 
	 if(isset($request['todotextnews'])!=''){
		  $todotextnews = $request['todotextnews'];
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($request['todostatusnews'])){
		   $todostatusnews = $request['todostatusnews'];
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		 $array = array_map('current', $todotextnews);
	  // -- to do list 
		if(!empty($todotextnews_array)){
			$count = count($todotextnews_array);	
			for($i=0;$i<$count;$i++){
				if(isset($todotextnews_array[$i])){		
					if(isset($todostatusnewss[$i])==''){					
						/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
							'Title' => $todotextnews_array[$i],
							'EntryId' => $EnterId,
							'IsActive' =>  '0',
							'PredefineType'=>'3'				 
							)
						);	 */			

					}else{					
							/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
							array('PredefinedNoteId' => '2',
							'Title' => $todotextnews_array[$i],
							'EntryId' => $EnterId,
							'IsActive' =>  $todostatusnewss[$i],
							'PredefineType'=>'3'				 
							)
						); */
					}
				} 

			}
		}
	   
		if(isset($request['createiveidea'])!=''){
		  $createiveidea = $request['createiveidea'];
		}else {
		  $createiveidea = array();	
		}
		$createiveidea = $request['createiveidea'];
		$createiveidea_array = array_map('current', $createiveidea);
		if(isset($request['ideaatus'])){
		   $ideaatus = $request['ideaatus'];
		   $ideaatuss = array_map('current', $ideaatus);
		}else{
			$ideaatus = array();
			$ideaatuss = array();
			
		}
		
		 if(!empty($createiveidea_array)){
		 $countsss = count($createiveidea_array);	
		 for($i=0;$i<$countsss;$i++){
			
			 if(isset($createiveidea_array[$i])){		
			if(isset($ideaatuss[$i])==''){					
					/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
					array('PredefinedNoteId' => '2',
						 'Title' => $createiveidea_array[$i],
						 'EntryId' => $EnterId,
						 'IsActive' =>  '0',
						 'PredefineType'=>'4'				 
						 )
					);	 */			
				
			}else{					
				/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '2',
					 'Title' => $createiveidea_array[$i],
					 'EntryId' => $EnterId,
					 'IsActive' =>  $ideaatuss[$i],
					 'PredefineType'=>'4'				 
					 )
				); */
			 }
			} 
			
		}
	 }
	 
	 // -- second simple Notes footer left 2
	 
	  if(!empty($secondsimpleNotes_array)){
		 $count = count($secondsimpleNotes_array);	
		 for($i=0;$i<$count;$i++){		
			 
			 if(isset($secondsimpleNotes_array[$i])!=''){	
				 if(isset($secondsimpleNotesstatus_array[$i])==''){
					/*  $InsertID = DB::table('diary_entry_todos')->insertGetId(
					array('PredefinedNoteId' => '2',
						'Title' => $secondsimpleNotes_array[$i],
						 'EntryId' => $EnterId,
						 'IsActive' => '0',
						 'PredefineType'=>'5'			 
						 )
					); */
				 }
				 else{
					 /* $InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								'Title' => $secondsimpleNotes_array[$i],
								 'EntryId' => $EnterId,
								 'IsActive' => $secondsimpleNotesstatus_array[$i],
								 'PredefineType'=>'5'			 
								 )
						); */
				}
			 }
			
		}
	 }
	  // -- secondNotes
	  
	  
		 if(!empty($secondNotes)){
			 $countss = count($secondNotes);	
			 for($i=0;$i<$countss;$i++){			
				/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => $secondNotes[$i],
					 'EntryId' => $EnterId,
					 'IsActive' => '1',
					 'PredefineType'=>'2'					 
					 )
				); */
			}
		 }
	 
	  
	 
		// 5 hate note
		  if(!empty($fivehatenote)){
			 $count = count($fivehatenote);	
			 for($i=0;$i<$count;$i++){			
				/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '1',
					 'Title' => $fivehatenote[$i],
					 'EntryId' => $EnterId,
					 'IsActive' => '0',
					 'PredefineType'=>'7'					 
					 )
				); */
			}
		 }
		// 5 like note
		 if(!empty($fivelikenote)){
			 $count = count($fivelikenote);	
			 for($i=0;$i<$count;$i++){			
				/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
				array('PredefinedNoteId' => '1',
					 'Title' => $fivelikenote[$i],
					 'EntryId' => $EnterId,
					 'IsActive' => '0',
					 'PredefineType'=>'8'					 
					 )
				); */
			}
		 }
		// marketing entry
		 if(!empty($marketing)){
			 $count = count($marketing);
			 for($i=0;$i<$count;$i++){
				  /*  DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '2',
						 'NoteText' => $marketing[$i]				 
						 )
					); */
			 }
			 
		}
		// report entry
		 if(!empty($report)){
			 $count = count($report);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '4',
						 'NoteText' => $report[$i]					 
						 )
					);
			 }
			  
		}
		// notes entry
		 if(!empty($notes)){
			 $count = count($notes);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '5',
						 'NoteText' => $notes[$i]					 
						 )
					);
			 }
		}
		// home entry
		 if(!empty($home)){
			 $count = count($home);
			 for($i=0;$i<$count;$i++){
				   DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $EntryDate,
						 'UserId' => session()->get('UserLoginId'),
						 'PredefinedNoteId' => '11',
						 'NoteText' => $home[$i],					 
						 )
					);
			 }
			 
		}
		return 1;
		
	}

	/* Destroyed entry */
	public function destroyedEntry($tablename,$para,$value){			 
		DB::table($tablename)
		->where($para, $value)		    
		->delete();
		return 1;
	}
	/* Habit section Edit Entry */	
	public function habitedit($habit,$mynewdate){		 
		if(!empty($habit)){
		$count = count($habit);
		$userId = session()->get('UserLoginId');
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entries')->insertGetId(
			
			array('EntryDate' => $mynewdate,
				 'UserId' => $userId,
				 'SectionId' => '1',
				 'PredefinedNoteId'=>$habit[$i],
				'NoteText'=>'',
				'NoteTypeId'=>'4',
				'IsActive'=>'1',
				'created_at'=>date('Y-m-d H:i:s'),
				 )
				 
			);
		}
		}
		return 1;
	}
	/* Routine Habit section Edit Entry */	
	public function routineedit($secondNotes,$mynewdate){		 
		if(!empty($secondNotes)){
		 $count = count($secondNotes);	
		 $userId = session()->get('UserLoginId');
		 for($i=0;$i<$count;$i++){			
			$InsertID = DB::table('diary_entries')->insertGetId(
			
			array('EntryDate' => $mynewdate,
				 'UserId' => $userId,
				 'SectionId' => '7',
				 'PredefinedNoteId'=>$secondNotes[$i],
				'NoteText'=>'',
				'NoteTypeId'=>'4',
				'IsActive'=>'1',
				'created_at'=>date('Y-m-d H:i:s'),
				 )
			);
		}
		}
		return 1;
	}
	/* Market section Edit Entry */	
	public function marketedit($marketing,$mynewdate){		 
		if(!empty($marketing)){
		 $count = count($marketing);	
		$userid = session()->get('UserLoginId');
			$EntryRecord = DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)
			->where('SectionId','2')
			->get();
			if(!empty($EntryRecord)){
				if(isset($EntryRecord[0]->EntryId)!=""){
					foreach($EntryRecord as $rec){
						$isd[]=$rec->EntryId;
					}
				 $cou = count($isd);
					for($i=0;$i<$cou;$i++){
						if(isset($marketing[$i])!=''){
							$title=$marketing[$i];
						}else{ $title='';}
						if($title!=''){}
						if($title!=''){
							DB::table('diary_entries')
							   ->where('EntryId', $isd[$i])
								  ->update(
								   array('EntryDate' => $mynewdate,
										 'UserId' => session()->get('UserLoginId'),
										 'PredefinedNoteId' => '0',
										 'NoteText' => $title,
										 'SectionId'=>'2',
										 'NoteTypeId'=>'1',
										 'updated_at'=>date('Y-m-d'),
										 )
								);
							}
						}
					}
				}
			
			}
			return 1;
		}
		
	/* Market section add Entry */	
	public function marketedit1($marketing,$mynewdate){		 
		if(!empty($marketing)){
		 $count = count($marketing);	
		 for($i=0;$i<$count;$i++){	
			if($marketing[$i]!=''){
			$InsertID = DB::table('diary_entries')->insertGetId(
			array('EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'PredefinedNoteId' => '0',
				 'NoteText' => $marketing[$i],
				 'SectionId'=>'2',
				 'NoteTypeId'=>'1',
				 'created_at'=>date('Y-m-d'),
				 )
			);
			}
		}
		}
		return 1;
	}
	/* Hate section edit Entry */			
	public function hatesedit($fivehatenote,$mynewdate){
		$count = count($fivehatenote);	
		$userid = session()->get('UserLoginId');
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)				
			->where('SectionId','9')
			->get();
			
			if(!empty($PredefineDetail)){
				if(isset($PredefineDetail[0]->EntryId)!=""){
					foreach($PredefineDetail as $rec){
						$isd[]=$rec->EntryId;
					}
					$cou = count($isd);
					for($i=0;$i<5;$i++){
						if($fivehatenote[$i]!=''){
						DB::table('diary_entries')
						   ->where('EntryId', $isd[$i])
							  ->update(							  
							   array( 
									 'EntryDate' => $mynewdate,
									 'UserId' => $userid,
									 'SectionId' => '9',
									 'PredefinedNoteId' => '0',
									 'NoteText'=>$fivehatenote[$i],
									 'NoteTypeId'=>'1',
									 'updated_at'=>date('Y-m-d H:i:s'),
									 
									 )
							);
						}
					}
				}else{
					for($i=0;$i<5;$i++){
							if($fivehatenote[$i]!=''){
						$InsertID = DB::table('diary_entries')->insertGetId(						
						  array( 
									 'EntryDate' => $mynewdate,
									 'UserId' => $userid,
									 'SectionId' => '9',
									 'PredefinedNoteId' => '0',
									 'NoteText'=>$fivehatenote[$i],
									 'NoteTypeId'=>'1',
									 'created_at'=>date('Y-m-d H:i:s'),
									 
									 )
						);
							}
					}
				}
			}
			
		return 1;
	}

	/* Hate section add Entry */	
	public function hatesedit1($fivehatenote,$EnterId){
		$count = count($fivehatenote);	
		 for($i=0;$i<5;$i++){	
			if($fivehatenote[$i]!=''){
			/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => '1',
				 'Title' => $fivehatenote[$i],
				 'EntryId' => $EnterId,
				 'IsActive' => '0',
				 'PredefineType'=>'9'					 
				 )
			); */
			}
		}
		return 1;
	}
	/* Like section edit Entry */	
	public function likeedit($fivelikenote,$mynewdate){
		$count = count($fivelikenote);	
		$userid = session()->get('UserLoginId');
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)				
			->where('SectionId','10')
			->get();
			
			if(!empty($PredefineDetail)){
				if(isset($PredefineDetail[0]->EntryId)!=""){
					foreach($PredefineDetail as $rec){
						$isd[]=$rec->EntryId;
					}
					$cou = count($isd);
					for($i=0;$i<5;$i++){
						if($fivelikenote[$i]!=''){
						DB::table('diary_entries')
						   ->where('EntryId', $isd[$i])
							  ->update(							  
							   array( 
									 'EntryDate' => $mynewdate,
									 'UserId' => $userid,
									 'SectionId' => '10',
									 'PredefinedNoteId' => '0',
									 'NoteText'=>$fivelikenote[$i],
									 'NoteTypeId'=>'1',
									 'updated_at'=>date('Y-m-d H:i:s'),
									 
									 )
							);
						}
					}
				}else{
					for($i=0;$i<5;$i++){		
						if($fivelikenote[$i]!=''){					
						$InsertID = DB::table('diary_entries')->insertGetId(						
						  array( 
									 'EntryDate' => $mynewdate,
									 'UserId' => $userid,
									 'SectionId' => '10',
									 'PredefinedNoteId' => '0',
									 'NoteText'=>$fivelikenote[$i],
									 'NoteTypeId'=>'1',
									 'created_at'=>date('Y-m-d H:i:s'),
									 
									 )
						);
						}
					}
				}
			}
			
		return 1;
	}
	/* Like section add Entry */	
	public function likeedit1($fivelikenote,$EnterId){
		$count = count($fivelikenote);	
		 for($i=0;$i<5;$i++){		
			if($fivelikenote[$i]!=''){
			/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
			array('PredefinedNoteId' => '1',
				 'Title' => $fivelikenote[$i],
				 'EntryId' => $EnterId,
				 'IsActive' => '0',
				 'PredefineType'=>'8'					 
				 )
			); */
			}
		}
		return 1;
	}

	/* Report section add Entry */	
	public function reportadd($reports,$mynewdate){
		if(!empty($reports)){
		 $count = count($reports);	
		 for($i=0;$i<$count;$i++){			
		 if($reports[$i]!=''){
			$InsertID = DB::table('diary_entries')->insertGetId(
			array(
				'EntryDate' => $mynewdate,
				'UserId' => session()->get('UserLoginId'),
				'SectionId' => '4',
				'PredefinedNoteId' =>'0',
				'NoteText'=> $reports[$i],
				'NoteTypeId'=>'1',
				'created_at'=>date('Y-m-d H:i:s'),				 
				 )
			);
		 }
		}
		}
		return 1;		 
	}
	/* Report section edit entry reporteditnew*/
	public function reportedit($reports,$mynewdate){
		$userid = session()->get('UserLoginId');
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)				
			->where('SectionId','4')
			->get();
		
		if(!empty($PredefineDetail)){
			foreach($PredefineDetail as $predef){
				$ids[] = $predef->EntryId;
			}
		}
		$count = count($ids);
		for($i=0;$i<$count;$i++){	
			if($reports[$i]!=''){
			DB::table('diary_entries')
						   ->where('EntryId', $ids[$i])
							  ->update(
							   array( 
									'EntryDate' => $mynewdate,
									'UserId' => $userid,
									'SectionId' => '4',
									'PredefinedNoteId' => '0',
									'NoteText'=>$reports[$i],
									'NoteTypeId'=>'1',
									'updated_at'=>date('Y-m-d H:i:s'),
									)
							
							);
			}
		}
		
		return 1;		 
	}
	/* Notes section Edit Entry */
		public function notesedit($notes,$mynewdate){
		$userid = session()->get('UserLoginId');
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)				
			->where('SectionId','5')
			->get();
		
		if(!empty($PredefineDetail)){
			foreach($PredefineDetail as $predef){
				$ids[] = $predef->EntryId;
			}
		}
		$count = count($ids);
		for($i=0;$i<$count;$i++){
			if($notes[$i]!=''){
			DB::table('diary_entries')
						   ->where('EntryId', $ids[$i])
							  ->update(
							   array( 
									'EntryDate' => $mynewdate,
									'UserId' => $userid,
									'SectionId' => '5',
									'PredefinedNoteId' => '0',
									'NoteText'=>$notes[$i],
									'NoteTypeId'=>'1',
									'updated_at'=>date('Y-m-d H:i:s'),
									)
							
							);
			}
		}
		
		return 1;	
		}
	
	
	/* Report section add Entry */	
	public function notesadd($notes,$mynewdate){
		if(!empty($notes)){
		 $count = count($notes);	
		 for($i=0;$i<$count;$i++){	
			if($notes[$i]!=''){
			$InsertID = DB::table('diary_entries')->insertGetId(
			 
				 array(
				 'EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'SectionId' => '5',
				 'PredefinedNoteId' => '0',
				 'NoteText'=>$notes[$i],
				 'NoteTypeId'=>'1',
				 'created_at'=>date('Y-m-d')
				 )
			);
			}
		}
		}
		return 1;
		}
	
	/* Home section add Entry */	
	public function homeadd($home,$mynewdate){
		if(!empty($home)){
		 $count = count($home);	
		 for($i=0;$i<$count;$i++){
			if($home[$i]!=''){
			$InsertID = DB::table('diary_entries')->insertGetId(
			array('EntryDate' => $mynewdate,
				 'UserId' => session()->get('UserLoginId'),
				 'SectionId'=>'11',
				 'PredefinedNoteId' => '0',
				 'NoteText' => $home[$i],
				 'NoteTypeId'=>'1',
				 'created_at'=>date('Y-m-d H:i:s'),
				 )
			);
			}
		}
		}
		return 1;
	}
	
	/* Home section edit Entry */	
	public function homeedit($home,$mynewdate){
		$userid = session()->get('UserLoginId');
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)				
			->where('SectionId','11')
			->get();
		
		if(!empty($PredefineDetail)){
			foreach($PredefineDetail as $predef){
				$ids[] = $predef->EntryId;
			}
		}
		$count = count($ids);
		for($i=0;$i<$count;$i++){
			if($home[$i]!=''){
				DB::table('diary_entries')
						   ->where('EntryId', $ids[$i])
							  ->update(
							   array( 
									'EntryDate' => $mynewdate,
									'UserId' => $userid,
									'SectionId' => '11',
									'PredefinedNoteId' => '0',
									'NoteText'=>$home[$i],
									'NoteTypeId'=>'1',
									'updated_at'=>date('Y-m-d H:i:s'),
									)
							
							);
			}
		}
		return 1;
	}
	/* Idea section edit Entry */	
	public function ideaeditfrm($ideaatus,$createiveidea,$EnterId){
		$ideaatus = $ideaatus;
		$createiveidea = $createiveidea;
		// -- creative ideas
		$createiveidea = $createiveidea;
		if(isset($ideaatus)){
			$ideaatus = $ideaatus;
		}else{
		   $ideaatus = array('0','0','0','0','0','0','0','0','0','0');
		}

		if(!empty($createiveidea)){
		 $count = count($createiveidea);	
		 for($i=0;$i<$count;$i++){
			 if(isset($createiveidea[$i])){		
				 count($createiveidea[$i]);
				
				 if(isset($ideaatus[$i])==''){
					 if(count($createiveidea[$i]) > 1){
					for($j=0;$j<count($createiveidea[$i]);$j++){
							/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
										array('PredefinedNoteId' => '2',
										 'Title' => $createiveidea[$i][$j],
										 'EntryId' => $EnterId,
										 'IsActive' =>  '0',
										 'PredefineType'=>'4'
									)										 
								 ); */
					}
				}else{
					/*  $InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								 'Title' => $createiveidea[$i][0],
								 'EntryId' => $EnterId,
								 'IsActive' =>  '0',
								 'PredefineType'=>'4'	)			 
								 ); */
				}
				 }else{
					
					 if(count($createiveidea[$i]) > 1){
						
					for($j=0;$j<count($createiveidea[$i]);$j++){
						if(isset($createiveidea[$i][$j])=='1'){
							$check= '1';
						}else{
							$check ='0';
						}
						/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
						array('PredefinedNoteId' => '2',
								 'Title' => $createiveidea[$i][$j],
								 'EntryId' => $EnterId,
								 'IsActive' =>  $check ,
								 'PredefineType'=>'4'	)			 
								 ); */
					}
				}else{
					if(isset($createiveidea[$i])=='1'){
							$check= '1';
						}else{
							$check ='0';
						}
					/* $InsertID = DB::table('diary_entry_todos')->insertGetId(
					  array('PredefinedNoteId' => '2',
						 'Title' => $createiveidea[$i][0],
						 'EntryId' => $EnterId,
						 'IsActive' =>  $check ,
						 'PredefineType'=>'4'	)			 
						 ); */
				}
				 }
				
			} 
			
		}
		}
	}
	/* Primary simple note section edit Entry */	
	public function primarynoteedit($secondsimpleNotesstatus,$secondsimpleNotes,$mynewdate){
		//echo '<pre>';print_r($secondsimpleNotesstatus);print_r($secondsimpleNotes);die;
		if(!empty($secondsimpleNotesstatus)){
			$secondsimpleNotesstatus_count = count($secondsimpleNotesstatus);
		}if(!empty($secondsimpleNotes)){		
			$secondsimpleNotes_count = count($secondsimpleNotes);
		}
		$userid = session()->get('UserLoginId');	
		//echo '<pre>';print_r($secondsimpleNotesstatus_count);print_r($secondsimpleNotes_count);die;
		 $PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdate)
			->where('UserId',$userid)				
			->where('SectionId','8')
			->get();
			//echo 'dd';print_r($PredefineDetail);die;
			
									 
			 if(!empty($EntryRecord)){
				
				if(isset($EntryRecord[0]->EntryId)!=""){ 
					foreach($EntryRecord as $rec){
						$isd[]=$rec->EntryId;
					}
					
					
					$cou = count($isd);
					for($i=0;$i<13;$i++){
						if($secondsimpleNotes[$i][0]!='') {
						if(isset($secondsimpleNotesstatus[$i])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}
						DB::table('diary_entries')
						   ->where('EntryId', $isd[$i])
							  ->update(
							  array( 
									'EntryDate' =>$mynewdate,
									'UserId' => $userid,
									'SectionId' => '8',
									'PredefinedNoteId' => '0',
									'NoteText'=>$secondsimpleNotes[$i][0],
									'NoteTypeId'=>'2',
									'IsActive'=>$status,
									'created_at'=>date('Y-m-d H:i:s'),
								)
								
							);
						}
					}
				}else{
					for($i=0;$i<13;$i++){	
					if($secondsimpleNotes[$i][0]!='') {
						if(isset($secondsimpleNotesstatus[$i])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}						
						$InsertID = DB::table('diary_entries')->insertGetId(
						
							 array( 
									'EntryDate' =>$mynewdate,
									'UserId' => $userid,
									'SectionId' => '8',
									'PredefinedNoteId' => '0',
									'NoteText'=>$secondsimpleNotes[$i][0],
									'NoteTypeId'=>'2',
									'IsActive'=>$status,
									'created_at'=>date('Y-m-d H:i:s'),
								)
								
						);
					}
					}
				}
			}else{
				for($i=0;$i<13;$i++){	
					if($secondsimpleNotes[$i][0]!='') {
						if(isset($secondsimpleNotesstatus[$i])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}						
						$InsertID = DB::table('diary_entries')->insertGetId(
						
							 array( 
									'EntryDate' =>$mynewdate,
									'UserId' => $userid,
									'SectionId' => '8',
									'PredefinedNoteId' => '0',
									'NoteText'=>$secondsimpleNotes[$i][0],
									'NoteTypeId'=>'2',
									'IsActive'=>$status,
									'created_at'=>date('Y-m-d H:i:s'),
								)
								
						);
					}
					}
			}  
	 return 1;
		
	}
	/* Idea section edit entry */
	public function ideaedit($ideaatus,$createiveidea,$mynewdated){
		$todotextnews_array = $createiveidea;
		$todostatusnews = $ideaatus;
		$userid = session()->get('UserLoginId');	
					
		
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdated)
			->where('UserId',$userid)				
			->where('SectionId','6')
			->get();
		
		if(!empty($PredefineDetail)){
			foreach($PredefineDetail as $predef){
				$ids[] = $predef->EntryId;
			}
		}
		$count = count($ids);
		for($i=0;$i<$count;$i++){
		
			if(isset($todostatusnews[$i][0])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}
						if($todotextnews_array[$i][0]!=''){
						DB::table('diary_entries')
						   ->where('EntryId', $ids[$i])
							  ->update(
							   array( 
									'EntryDate' => $mynewdated,
									'UserId' => $userid,
									'SectionId' => '6',
									'PredefinedNoteId' => '0',
									'NoteText'=>$todotextnews_array[$i][0],
									'NoteTypeId'=>'3',
									'IsActive'=>$status,
									'updated_at'=>date('Y-m-d H:i:s'),
									)
							
							);
						}
		}
		return 1;
		
	}
	/* Idea section add Entry */	
	public function ideaaddfrm($ideaatus,$createiveidea,$mynewdate){
		$userid = session()->get('UserLoginId');		
		if(isset($createiveidea)!=''){
		  $todotextnews = $createiveidea;
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($ideaatus)){
		   $todostatusnews = $ideaatus;
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		 $array = array_map('current', $todotextnews);
		// -- to do list 
		if(!empty($todotextnews_array)){
		 $count = count($todotextnews_array);	
		 for($i=0;$i<$count;$i++){
			 if(isset($todotextnews_array[$i])){		
			if(isset($todostatusnewss[$i])==''){
					if($todotextnews_array[$i]!=''){
					$InsertID = DB::table('diary_entries')->insertGetId(
					array(
						'EntryDate' => $mynewdate,
						 'UserId' => $userid,
						 'SectionId' => '6',
						 'PredefinedNoteId' =>  '0',
						 'NoteText'=>$todotextnews_array[$i],
						 'NoteTypeId'=>'2',
						 'IsActive'=>'',
						 'created_at'=>date('Y-m-d H:i:s'),						 
						 )
						 
						 
					);	}			
				
			}else{	
				if($todotextnews_array[$i]!=''){
				$InsertID = DB::table('diary_entries')->insertGetId(
				array(
						'EntryDate' => $mynewdate,
						 'UserId' => $userid,
						 'SectionId' => '6',
						 'PredefinedNoteId' =>  '0',
						 'NoteText'=>$todotextnews_array[$i],
						 'NoteTypeId'=>'2',
						 'IsActive'=>$todostatusnewss[$i],
						 'created_at'=>date('Y-m-d H:i:s'),						 
						 )
				
				);
				}
			
			 
			 }
			} 
			
		}
		}
		return 0;
	}
	/* To do section edit Entry */	
	
	public function todoeditfrm($todostatusnews,$todotextnews,$mynewdated){
		$todotextnews_array = $todotextnews;
		$todostatusnews = $todostatusnews;
		$userid = session()->get('UserLoginId');	
					
		
		$PredefineDetail =  DB::table('diary_entries')
			->where('EntryDate',$mynewdated)
			->where('UserId',$userid)				
			->where('SectionId','3')
			->get();
		
		if(!empty($PredefineDetail)){
			foreach($PredefineDetail as $predef){
				$ids[] = $predef->EntryId;
			}
		}
		$count = count($ids);
		for($i=0;$i<$count;$i++){
		
			if(isset($todostatusnews[$i][0])=='1'){
							$status = '1';
						}else{
							$status = '0';
						}
						if($todotextnews_array[$i][0]!=''){
						DB::table('diary_entries')
						   ->where('EntryId', $ids[$i])
							  ->update(
							   array( 
									'EntryDate' => $mynewdated,
									'UserId' => $userid,
									'SectionId' => '3',
									'PredefinedNoteId' => '0',
									'NoteText'=>$todotextnews_array[$i][0],
									'NoteTypeId'=>'3',
									'IsActive'=>$status,
									'updated_at'=>date('Y-m-d H:i:s'),
									)
							
							);
						}
		}
	}
	
	
	public function todoeditfrm_bkup($todostatusnews,$todotextnews,$mynewdated){
		$todotextnews_array = $todotextnews;
		$todostatusnews = $todostatusnews;
		if(!empty($todotextnews_array)){
		 $count = count($todotextnews_array);
		$userid = session()->get('UserLoginId');		 
		 for($i=0;$i<$count;$i++){
			 if(isset($todotextnews_array[$i])){		
				 count($todotextnews_array[$i]);
				 if(isset($todostatusnews[$i])==''){
					 if(count($todotextnews_array[$i]) > 1){
					for($j=0;$j<count($todotextnews_array[$i]);$j++){
							$InsertID = DB::table('diary_entries')->insertGetId(
										

									array(
										'EntryDate' => $mynewdated,
										'UserId' => $userid,
										'SectionId' => '3',
										'PredefinedNoteId' =>  '0',
										'NoteText'=>$todotextnews_array[$i][$j],
										'NoteTypeId'=>'2',
										'IsActive'=>'0',
										'created_at'=>date('Y-m-d H:i:s'),
									)
									
								);
								 
					}
				}else{
					 $InsertID = DB::table('diary_entries')->insertGetId(
						

									array(
										'EntryDate' => $mynewdated,
										'UserId' => $userid,
										'SectionId' => '3',
										'PredefinedNoteId' =>  '0',
										'NoteText'=>$todotextnews_array[$i][0],
										'NoteTypeId'=>'2',
										'IsActive'=>'0',
										'created_at'=>date('Y-m-d H:i:s'),
									)
									
								 );
				}
				 }else{
					 if(count($todotextnews_array[$i]) > 1){
					for($j=0;$j<count($todotextnews_array[$i]);$j++){
						$InsertID = DB::table('diary_entries')->insertGetId(
								array(
										'EntryDate' => $mynewdated,
										'UserId' => $userid,
										'SectionId' => '3',
										'PredefinedNoteId' =>  '0',
										'NoteText'=>$todotextnews_array[$i][$j],
										'NoteTypeId'=>'2',
										'IsActive'=>'0',
										'created_at'=>date('Y-m-d H:i:s'),
									)
									
								 );
					}
				}else{
					$InsertID = DB::table('diary_entries')->insertGetId(
					array(
										'EntryDate' => $mynewdated,
										'UserId' => $userid,
										'SectionId' => '3',
										'PredefinedNoteId' =>  '0',
										'NoteText'=>$todotextnews_array[$i][0],
										'NoteTypeId'=>'2',
										'IsActive'=>'0',
										'created_at'=>date('Y-m-d H:i:s'),
									)
									
					  		 
								 );
				}
				 }
				
			} 
			
		}
		}

	}
	/* To do  section add Entry */	
	public function todoaddfrm($todostatusnewsss,$todotextnewsss,$mynewdate){
		if(isset($todotextnewsss)!=''){
		  $todotextnews = $todotextnewsss;
		  $todotextnews_array = array_map('current', $todotextnews);
		}else {
		  $todotextnews = array();	
		}
		if(isset($todostatusnewsss)){
		   $todostatusnews = $todostatusnewsss;
		   $todostatusnewss = array_map('current', $todostatusnews);
		}else{
			$todostatusnews = array();
			$todostatusnewss = array();
			
		}
		 $array = array_map('current', $todotextnews);
		// -- to do list 
		if(!empty($todotextnews_array)){
		 $count = count($todotextnews_array);	
		 for($i=0;$i<$count;$i++){
			 if(isset($todotextnews_array[$i])){		
			if(isset($todostatusnewss[$i])==''){
					if($todotextnews_array[$i]!=''){
					$InsertID = DB::table('diary_entries')->insertGetId(
					array('EntryDate' => $mynewdate,
						 'UserId' => session()->get('UserLoginId'),
						 'SectionId' => '3',
						 'PredefinedNoteId' =>  '0',
						 'NoteText'=> $todotextnews_array[$i],
						 'NoteTypeId'=>'2',
						 'IsActive'=>'',
						 'created_at'=>date('Y-m-d H:i:s'),					 
						 )
						 
					);	
					}					
				
			}else{			
				if($todotextnews_array[$i]!=''){
				$InsertID = DB::table('diary_entries')->insertGetId(
				
					 	array('EntryDate' => $mynewdate,
						 'UserId' => session()->get('UserLoginId'),
						 'SectionId' => '3',
						 'PredefinedNoteId' =>  '0',
						 'NoteText'=> $todotextnews_array[$i],
						 'NoteTypeId'=>'2',
						 'IsActive'=>$todostatusnewss[$i],
						 'created_at'=>date('Y-m-d H:i:s'),					 
						 )
				);
				}
			
			 
			 }
			} 
			
		}
		}
		return 0;
	}
	/* Get record by date with parameter */	
	public function getRecordByDateBypara($date){
		 $PredefineDetail = DB::table('diary_entries')
				->whereNull('PredefinedNoteId')	
				->where('EntryDate', $date)				//whereNotNull
				->get();
		return $PredefineDetail;
	 }
	/* Destroyed entry with parameter */
	public function destroyedEntrywithpara($tablename,$para,$value,$par1,$val1){		
		DB::table($tablename)->where($para, $value)->where($par1, $val1)->delete();
		return 1;
	}
	/* Delete entry with three paramenter used */
	public function destroyedEntrywithparathree($tablename,$para,$value,$par1,$val1,$par2,$val2){		
		DB::table($tablename)->where($para, $value)->where($par1, $val1)->where($par2, $val2)->delete();
		return 1;
	}
	/* Destroyed entry with parameter */
	public function destroyedEntrywithpara1($value){
		DB::table('diary_entries')->where('SectionId', '9')->where('EntryDate', $value)->delete();				
		return 1;
	}
	/* using join query for two table */
	public function getjoinquery($sectionid){
		$tes = DB::table("section_predefine_notes")
		->join("predefined_notes", "section_predefine_notes.PredefinedNoteId", "=", "predefined_notes.id")
		->select ("predefined_notes.*")
		->where("section_predefine_notes.SectionId",$sectionid)
		->get();
		return $tes;
	}
	 
    
    
    
}
