<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class PlanTopic extends Model
{
	/* Get by  record using Id  */
    public function getRecordById($tablename,$parameter,$value){
		$PredefineDetail = DB::table($tablename)
			->where($parameter,$value)	
			->orderBy('id', 'DESC')
			->get();
		return $PredefineDetail;
	}
	/* Get Record bu two parameter */
	public function getRecordByIdtwopara($tablename,$parameter,$value){
		$PredefineDetail = DB::table($tablename)
			->where($parameter,$value)	
			->where('topicstatus','1')	
			->orderBy('id', 'DESC')			
			->get();
		return $PredefineDetail;
	}
	/* Store / insert plan topics function  */
	public function store($request){
		
		$planedate = $request->input('planedate');
		$planeid = $request->input('planeid');
		$plantext = $request->input('plantext');
		$userid = $request->session()->get('UserLoginId');
		if($planedate!='' && $planeid!='' && $userid!='' && $plantext!=''){		
		$count = count($plantext);
		for($i=0;$i<$count;$i++){
			$checkrec = DB::table('plan_topics')
			->where('planid',$planeid)	
			->where('UserId',$userid)	
			->where('topictext',$plantext[$i])
			->get();
			if(isset($checkrec[0]->id)==''){
				DB::table('plan_topics')->insertGetId(
				array(
					'planid' => $planeid,
					'duedate' => $planedate,
					'UserId'=>$userid,
					'topictext'=>$plantext[$i],
					'topicstatus'=>'1',
					'created_at' => date('Y-m-d H:i:s')
					)
				);	
			}			
		}
			return 1;
		}else{
			return 2;
		}
	}
	/* update plan topic function */
	public function updatetopic($request){		
		$topicid = $request->input('topicid');
		$planid = $request->input('planid');
		$topics = $request->input('topics');
		$userid = $request->session()->get('UserLoginId');
		
		if($topics!='' && $topicid!='' && $planid!=''){
			DB::table('plan_topics')
				->where('id', $topicid)
				->update(
				array('planid' => $planid,
					'UserId'=>$userid,
					'topictext'=>$topics,
					'topicstatus'=>'1',
					'updated_at' => date('Y-m-d H:i:s')
					 )
			);
			return 1;
		}
		return 0;
	}
	/* Delete plan topic function */
	public function removeAction($id){
		$topicid = $id;
		if($id!=''){
			DB::table('plan_topics')
				->where('id', $topicid)
				->update(
				array(
					'topicstatus'=>'0',
					'updated_at' => date('Y-m-d H:i:s')
					 )
			);
			return 1;
		}
		return 0;
	}
}
