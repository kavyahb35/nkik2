<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class DiaryEntryTodo extends Model
{
	/* Get Record by Id with Type  */
	public function getRecordByIdType($tablename,$parameter,$value,$value1){
	 
		$PredefineDetail = DB::table($tablename)
			->where($parameter,$value)	
			->where('PredefineType',$value1)	
			->get();
		return $PredefineDetail;
	}
	/* Delete Entry by ID */
	public function destroyId($Id){
	   DB::delete('delete from diary_entry_todos  where EntryId= ?',[$Id]);    
	   return 1; 	 
	}
	/* Delete Entry by Date */
	public function destroyedEntry($date){			 
		DB::table('diary_entries')
		->where('EntryDate', $date)
		->whereNotNull('PredefinedNoteId')
		->delete();
		return 1;
	}
}
