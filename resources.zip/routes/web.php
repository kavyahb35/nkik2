<?php
Route::get('/', 'UserController@index');
Route::get('index', 'UserController@index');
Route::post('login', 'UserController@login');
Route::get('logout', 'UserController@logout');

Route::get('dashboard', 'UserController@dashboard');
Route::get('dairy', 'DiaryEntryNewController@index');
Route::get('create-diary', 'DiaryEntryNewController@create');
Route::post('create-diary', 'DiaryEntryNewController@create');
Route::post('create-diary-entry', 'DiaryEntryNewController@store');
Route::get('dairy-entry/{id}', 'DiaryEntryNewController@edit');
Route::post('update-entry/{id}', 'DiaryEntryNewController@update');



Route::get('dairy/{id}/get', 'DiaryEntryNewController@getDairy');
Route::post('dairy/{id}/edit', 'DiaryEntryNewController@updateEntry');

Route::get('delete-entry/{id}', 'DiaryEntryNewController@deleteEntry');
Route::get('view-entry/{id}', 'DiaryEntryNewController@viewEntry');

Route::post('view-diary-entry', 'DiaryEntryNewController@viewDiaryEntry');

Route::post('market-form-add', 'DiaryEntryNewController@marketadd');
Route::post('edit-create-diary', 'DiaryEntryNewController@dateDiaryEntry');

Route::get('goal', 'GoalController@index');
Route::get('tag', 'TagController@index');

Route::get('diary-entries/{id}', 'DiaryEntryNewController@byDateEntry');

Route::post('wellness-edit-habit', 'DiaryEntryNewController@wellnessedithabit');

Route::post('wellness-edit', 'DiaryEntryNewController@wellnessedit');
Route::post('market-form-edit', 'DiaryEntryNewController@marketedit');

Route::post('todo-form-edit', 'DiaryEntryNewController@todoeditfrm');
Route::post('todo-form-add', 'DiaryEntryNewController@todoaddfrm');
Route::post('report-form-add', 'DiaryEntryNewController@reportaddfrm');
Route::post('report-form-edit', 'DiaryEntryNewController@reporteditfrm');
Route::post('notes-form-edit', 'DiaryEntryNewController@noteseditfrm');
Route::post('notes-form-add', 'DiaryEntryNewController@notesaddfrm');
Route::post('idea-form-edit', 'DiaryEntryNewController@ideaeditfrm');
Route::post('idea-form-add', 'DiaryEntryNewController@ideaaddfrm');
Route::post('hate-form-edit', 'DiaryEntryNewController@hateeditfrm');
Route::post('like-form-edit', 'DiaryEntryNewController@likeeditfrm');
Route::post('home-form-edit', 'DiaryEntryNewController@homeeditfrm');
Route::post('home-form-add', 'DiaryEntryNewController@homeaddfrm');
Route::post('routine-form-edit', 'DiaryEntryNewController@routineformedit');

/* Plan */

Route::get('plan', 'PlanController@index');
Route::post('add-plan', 'PlanController@create');
Route::get('search-plan/{id}', 'PlanController@autosearch');

Route::post('edit-plan/{id}', 'PlanController@edit');
Route::get('delete-plan/{id}', 'PlanController@deleteplan');
/* Plan topic */
Route::get('plan-topic/{id}', 'PlantopicController@index');
Route::post('all-plan-topic/{id}', 'PlantopicController@allPlanTopic');
Route::post('plan-action/{id}', 'PlantopicController@create');
Route::get('view-action/{id}', 'PlantopicController@viewAction');
Route::post('action-update', 'PlantopicController@updateAction');
Route::get('delete-action/{id}', 'PlantopicController@deleteAction');

