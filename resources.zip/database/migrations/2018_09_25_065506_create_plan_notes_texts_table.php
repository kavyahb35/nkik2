<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlanNotesTextsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('plan_notes_texts', function (Blueprint $table) {
            $table->increments('id');
			$table->integer('planid');
            $table->date('duedate');
            $table->integer('UserId');
            $table->text('topictext')->nullable();
            $table->integer('IsDeleted')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('plan_notes_texts');
    }
}
