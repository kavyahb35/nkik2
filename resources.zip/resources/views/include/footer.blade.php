  
    <footer id="" class="bg-dark1 text-auto row  align-items-center px-6">
        <a style="float:right;color:#fff;" href="" target="_blank">
          Powered by Cuiek Diary
        </a>
    </footer>
	<style>
	
	.bg-dark1 {
		background: #343a40!important;
		display: block;
		position: relative;			
		padding: 9px 12px 32px 2px;
	}		
	</style>
  

