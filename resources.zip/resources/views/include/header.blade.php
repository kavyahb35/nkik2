 <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0 mdp1" href="#" style="">Cuiek Diary</a>		
		<div class="header-cls">
		<i class="fa fa-user"></i> {{ session()->get('UserLoginName') }}   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="{{ url('logout') }}"><i class="fa fa-sign-out"></i></a>
		</div>
    </nav>
	
