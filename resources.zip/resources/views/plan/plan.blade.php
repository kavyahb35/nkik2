@extends('layout.inner')
@section('content')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
   <h1 class="h2 plangead">Plan</h1>
   <!--- Plan search --->
 <div class="searchdiv">
			<form id="planid" name="planid">
				<!-- Search form -->
				<div class="input-group" >				  
					<input type="text" class="form-control" placeholder="Search for.." aria-describedby="sizing-addon2" name="searchplan" id="searchplan" onkeyup="showResult(this.value)">
					<span class="input-group-addon" id="sizing-addon2"><i class="fa fa-search"></i></span>
				</div>
				<div id="kp1" class="exits"></div>
				<script>
                           function showResult(val){
								var url="{{ url('search-plan') }}"+'/'+val;
								$.ajax({
								   type: 'get',
								   dataType : 'json',
								   url: url,
								   data: "category="+val,
								   success: function (data) {
									 $("#kp1").html(data);
								   }
								}
								);
                           }
                        </script>
			</form>
	   </div>
   <!--- end search --->
   <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group">&nbsp;&nbsp;&nbsp;
         <a class="right-align planbtn" title="Add New Plan" data-toggle="modal" href="#plan"><span><i class="fa fa-plus"></i> </span></a>
         
      </div>
   </div>
</div>
	  
	
<div>
	@if ($error != '' ) 
		<div class="alert alert-danger" id="messagehide">
		<strong>{{ $error }}</strong>
		</div>
	@endif

	@if ($success != '' ) 
		<div class="alert alert-success" id="messagehide1">
		<strong>{{ $success }}</strong>
		</div>
	@endif
		  
		  
	<script>
	$(document).ready(function(){    
			 $("#messagehide").fadeOut(2500)
			 $("#messagehide1").fadeOut(2500)
	});
	</script>
</div>
<div>
@php  $date = date('Y-m-d'); @endphp
	<div class="row">
		@if(!empty($listPlans))
			@foreach($listPlans as $plans)
		<div class="col-md-6 col-lg-4 col-sm-12 col-xs-12">
			<div class="planbox">
			
			@if(isset($plans->plantext)!='')
			<h6><a href="{{ url('plan-topic'.'/'.$plans->id) }}" target='_blank'>
				{{ $plans->plantext }}
			@if($plans->duedate >= $date)
				<span class="right-align green">
			@else 
				<span class="right-align red">
			@endif
			@php $duedate = $plans->duedate;
			echo $secondLastDate1 =  date('j M Y', strtotime($duedate)) @endphp  </span>
			</a></h6>
			@endif
			</div>
		</div>
		@endforeach
		@endif
	</div>
</div>
<?php //print_r($listPlans);?>
<!---- Add plan code model ---->
<div id="plan" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Add New Plan </h4>
         </div>
         <div class="modal-body">
            <form method="post" id="planform" name="planform" action="{{ url('add-plan')}}">
               {{csrf_field()}}
               <div class="box">
                 
				 <div class='input-group'>
				 <input type="text" name="plantext" id="plantext" required class="form-control" placeholder="Enter New Plan here.." >
				  </div><br>
				  <div class='input-group date' id='EntryDate'>
					<input type='text' class="form-control" name="duedate" id="duedate" required readonly value="" placeholder="Select Due date"  />
				 </div><br>	
                <div class="">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary" >&nbsp;&nbsp;&nbsp;
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
</div>
<!---- End add plan model---->
<style>
  .bg-dark1{  margin-top: 50%; }
</style>
@include('include.footer')

@endsection