@extends('layout.inner')
@section('content')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
   <h1 class="h2">Plan - @if(isset($plan[0]->plantext)) {{ $plan[0]->plantext }} 
   <span style="float:right">  {{ $plan[0]->duedate }} 
		
   </span> 
   @endif</h1>
   <!--- Plan search --->
 <style>
 input[type="checkbox"]{
	appearance: none;
	background: #fff;
	border:1px solid #ccc;
	border-radius: 1px;
	box-sizing: border-box;
	position: relative;
	box-sizing: content-box ;
	width: 23px;
	height: 20px;
	border-width: 0;
	transition: all .3s linear;
	margin-top: 1px;
}

 </style>
   <!--- end search --->
  
   <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group">&nbsp;
         <a class="right-align planbtn white" title="Edit Plan" data-toggle="modal1" onclick="editplan()" ><span><i class="fa fa-edit"></i> </span></a>         
      </div>
   </div>
   <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group">&nbsp;
         <a class="right-align planbtn white" title="Delete Plan"  onclick="deletemainplan('@php echo $plan[0]->id @endphp')" ><span><i class="fa fa-trash"></i> </span></a>         
      </div>
   </div>
</div>







<div class="d-flex">
   <h6 class=""> Show all Inactive </h6>
   <!--- Plan search --->
 
   <!--- end search --->
   <div  class="">
	   <div class="btn-group">&nbsp;&nbsp;&nbsp;
			<form method="post" action="{{ url('all-plan-topic/'.$plan[0]->id)}}" name="allvalueform" id="allvalueform" >
				{{csrf_field()}}
			<input id="check1" type="checkbox" name="allval" class="ss" value="1" onclick="allvalue()" @if($checkall=='1') checked  @endif>
			<input id="plnid" type="hidden" name="plnid" value="{{ $plan[0]->id }}" >
			</form>
	   </div>
    </div>
   <div class="">
      <div class="btn-group">&nbsp;&nbsp;&nbsp;
         <a class="right-align planbtn" title="Add More Plan Topic" data-toggle="modal" href="#plan"><span><i class="fa fa-plus"></i> </span></a>         
      </div>
   </div>
   
</div>







 <script>
	function allvalue(){
		  document.getElementById("allvalueform").submit();
	}
 </script>
	  
	
<div>
	@if ($error != '' ) 
		<div class="alert alert-danger" id="messagehide">
		<strong>{{ $error }}</strong>
		</div>
	@endif

	@if ($success != '' ) 
		<div class="alert alert-success" id="messagehide1">
		<strong>{{ $success }}</strong>
		</div>
	@endif
		  
		  
	<script>
	$(document).ready(function(){    
			 $("#messagehide").fadeOut(2500)
			 $("#messagehide1").fadeOut(2500)
	 });
	 
	</script>
</div>
<div>
@php  $date = date('Y-m-d'); @endphp
	<div class="row">
		@if(!empty($listPlans))
			@foreach($listPlans as $topic)
		<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
			<div class="planbox">
			
			@if(isset($topic->topictext)!='')
			
				{{ $topic->topictext }}
				<span class="rightcls fontcls">&nbsp;&nbsp;
			@if($topic->IsDeleted=='1')<a onclick="update('@php echo $topic->id @endphp')"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
			<a onclick="deletetopic('@php echo $topic->id @endphp')"><i class="fa fa-trash"></i></a>&nbsp;&nbsp; @endif
			</span>
				@if($topic->IsDeleted=='1')
					@if($topic->updated_at=='')<span class="rightcls"> Created on {{ $topic->created_at }}</span> 
					@else <span class="rightcls">Updated on {{ $topic->updated_at }}</span>
					@endif
					
				@else
					@if($topic->updated_at=='')<span class="rightcls"> Removed on {{ $topic->created_at }}</span> 
					@else <span class="rightcls">Removed on {{ $topic->updated_at }}</span>
					@endif
				@endif
			@endif
			</div>
		</div>
		@endforeach
		@endif
	</div>
</div>
<script>
 function update(id){
	var url="{{ url('view-action') }}"+'/'+id;
		$.ajax({
		   type: 'get',
		   dataType : 'json',
		   url: url,
		   data: "topic="+id,
		   success: function (data) {
			 $("#kp1").html(data);
			 $("#planactionedit").modal('show');
		   }
		}
		);
 }
 
  function deletetopic(id){
	  var url="{{ url('delete-action') }}"+'/'+id;
	  var r = confirm("Are You sure want to delete this Record?");
	   if (r == true) {
		  $.ajax({
			   type: 'get',
			   dataType : 'json',
			   url: url,
			   data: "topic="+id,
			   success: function () {
				   location.reload();
				 alert('Successfully remove plan topic.');
			   }
			}
			);
	   }
  }
  
  function deletemainplan(id){
	  var url="{{ url('delete-plan') }}"+'/'+id;
	  var returnurl="{{ url('plan') }}";
	  var r = confirm("Are You sure want to delete this Record?");
	   if (r == true) {
		  $.ajax({
			   type: 'get',
			   dataType : 'json',
			   url: url,
			   data: "topic="+id,
			   success: function () {
				   
				 alert('Successfully remove plan.');
				   window.location.href=returnurl;
				  // location.reload();
			   }
			}
			);
	   }
  }
</script>
<?php //print_r($listPlans);?>
<!---- Edit plan topic code  model ---->
<div id="planactionedit" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Edit Plan Topic  </h4>
         </div>
         <div class="modal-body">
            <form method="post" id="planformedit" name="planformedit" action="{{ url('action-update')}}">
               {{csrf_field()}}
               <div class="box">
                
				  <div id="kp1"></div>
				  <!--<div class='input-group date' id='EntryDate'>
					<input type='text' class="form-control" name="duedate" id="duedate" required readonly value="" placeholder="Select Due date"  />
				 </div>--><br>	
               <div class="">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary" >&nbsp;&nbsp;&nbsp;
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
</div>
<!---- End Edit plan topic model---->

<!---- Add plan code model ---->
<div id="plan" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Add New Plan Action  <a onclick="addmoreactions()"  ><i class="fa fa-plus plus"></i></a></h4>
         </div>
         <div class="modal-body">
            <form method="post" id="planform" name="planform" action="{{ url('plan-action/'.$plan[0]->id)}}">
               {{csrf_field()}}
               <div class="box">
                 <input type="hidden" name="planedate" value="@if(isset($plan[0]->duedate)) {{ $plan[0]->duedate }} @endif">
				 <input type="hidden" name="planeid" value="@if(isset($plan[0]->id)) {{ $plan[0]->id }} @endif">
				 <div class='input-group'>
				 <input type="text" name="plantext[]" id="plantext" required class="form-control" placeholder="Enter New Plan action here.." >
				  </div><br>
				  <div id="planaction"></div>
				  <!--<div class='input-group date' id='EntryDate'>
					<input type='text' class="form-control" name="duedate" id="duedate" required readonly value="" placeholder="Select Due date"  />
				 </div>--><br>	
               <div class="">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary" >&nbsp;&nbsp;&nbsp;
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
</div>
<!---- End add plan model---->

<script>
 function editplan(){
	 $("#planeditmain").modal('show');
 }
</script>

<!---- Add Edit code model ---->
<div id="planeditmain" class="modal fade in">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <a class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></a>
            <h4 class="modal-title">Edit Plan </h4>
         </div>
         <div class="modal-body">
            <form method="post" id="planform" name="planform" action="{{ url('edit-plan/'.$plan[0]->id )}}">
               {{csrf_field()}}
               <div class="box">
                 <input type="hidden" name="planids" value="{{ $plan[0]->id }}">
				 <div class='input-group'>
				 <input type="text" name="plantext" id="plantext" required class="form-control" placeholder="Enter New Plan here.." value="{{ $plan[0]->plantext }}" >
				  </div><br>
				  <div class='input-group date' id='EntryDate'>
					<input type='text' class="form-control" name="duedate" id="duedate" required readonly  placeholder="Select Due date"  value="{{ $plan[0]->duedate }}" />
				 </div><br>	
                <div class="">
                  <input type="submit" name="submit" value="Submit" class="btn btn-primary" >&nbsp;&nbsp;&nbsp;
                  <button class="btn btn-warning" data-dismiss="modal"><i class="fa fa-cancel"></i> Cancel</button>
               </div>
            </form>
         </div>
      </div>
      <!-- /.modal-content -->
   </div>
   <!-- /.modal-dalog -->
</div>
</div>
<!---- End Edit plan model---->

<script>
   var count = 0;
   function addmoreactions(){
      count += 1; 
      $('<div class="input-group"><input type="text" name="plantext[]" id="plantext" required class="form-control" placeholder="Enter New Plan action here.." ></div><br>').appendTo("#planaction");
   }
</script>
<!-- end code -->
<style>
  .bg-dark1{  margin-top: 50%; }
</style>
@include('include.footer')

@endsection